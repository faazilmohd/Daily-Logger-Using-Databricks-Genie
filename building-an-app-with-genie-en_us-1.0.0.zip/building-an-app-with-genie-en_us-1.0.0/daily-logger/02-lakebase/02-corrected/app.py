import os
import uuid
import time
import streamlit as st
import psycopg2
import psycopg2.extras
from databricks.sdk import WorkspaceClient

# ---------------------------------------------------------------------------
# Database connection with token refresh
# ---------------------------------------------------------------------------
PGHOST = os.environ["PGHOST"]
PGDATABASE = os.environ["PGDATABASE"]
PGUSER = os.environ["PGUSER"]
PGPORT = os.environ.get("PGPORT", "5432")

SCHEMA = "daily_logger"
TABLE = f"{SCHEMA}.journal_entries"

_token_cache = {"token": None, "refreshed_at": 0}


LAKEBASE = os.environ.get("LAKEBASE")

def _get_token() -> str:
    """Return a Lakebase OAuth token, refreshing every 15 minutes."""
    now = time.time()
    if _token_cache["token"] is None or now - _token_cache["refreshed_at"] > 900:
        w = WorkspaceClient()
        cred = w.postgres.generate_database_credential(
            endpoint=w.postgres.get_endpoint(LAKEBASE).name
        )
        _token_cache["token"] = cred.token
        _token_cache["refreshed_at"] = now
    return _token_cache["token"]


def get_conn():
    """Open a fresh psycopg2 connection with a valid token."""
    return psycopg2.connect(
        host=PGHOST,
        database=PGDATABASE,
        user=PGUSER,
        port=PGPORT,
        password=_get_token(),
        sslmode="require",
    )


# ---------------------------------------------------------------------------
# Bootstrap: ensure schema and table exist
# ---------------------------------------------------------------------------
def _bootstrap_db():
    conn = get_conn()
    conn.autocommit = True
    with conn.cursor() as cur:
        cur.execute(f"CREATE SCHEMA IF NOT EXISTS {SCHEMA}")
        cur.execute(f"""
            CREATE TABLE IF NOT EXISTS {TABLE} (
                id SERIAL PRIMARY KEY,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                body TEXT NOT NULL,
                mood VARCHAR(50) NOT NULL,
                blockers TEXT[] DEFAULT '{{}}'
            )
        """)
    conn.close()


_bootstrap_db()


# ---------------------------------------------------------------------------
# Data access helpers
# ---------------------------------------------------------------------------
def insert_entry(body: str, mood: str, blockers: list[str]):
    conn = get_conn()
    with conn.cursor() as cur:
        cur.execute(
            f"INSERT INTO {TABLE} (body, mood, blockers) VALUES (%s, %s, %s)",
            (body, mood, blockers),
        )
    conn.commit()
    conn.close()


def list_entries(limit: int = 50) -> list[dict]:
    conn = get_conn()
    with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute(
            f"SELECT id, created_at, body, mood, blockers FROM {TABLE} ORDER BY created_at DESC LIMIT %s",
            (limit,),
        )
        rows = cur.fetchall()
    conn.close()
    return rows


# ---------------------------------------------------------------------------
# Streamlit UI
# ---------------------------------------------------------------------------
MOODS = ["\U0001f60a Great", "\U0001f642 Good", "\U0001f610 Okay", "\U0001f61f Rough", "\U0001f62b Terrible"]

st.set_page_config(page_title="Daily Logger", page_icon="\U0001f4d3", layout="centered")
st.title("\U0001f4d3 Daily Logger")
st.caption("A personal work-journal app \u2014 entries persist in Lakebase")

# --- New entry form ---
st.header("New Entry")

with st.form("entry_form", clear_on_submit=True):
    body = st.text_area("What did you work on today?", height=150)
    mood = st.select_slider("Mood", options=MOODS, value="\U0001f642 Good")
    blockers_raw = st.text_input(
        "Blockers (comma-separated, optional)",
        placeholder="e.g. waiting on review, flaky test",
    )
    submitted = st.form_submit_button("Save Entry")

if submitted:
    if not body.strip():
        st.warning("Please write something before saving.")
    else:
        blockers = [b.strip() for b in blockers_raw.split(",") if b.strip()]
        insert_entry(body.strip(), mood, blockers)
        st.success("Entry saved!")

# --- History ---
st.divider()
st.header("History")

entries = list_entries()

if not entries:
    st.info("No entries yet \u2014 write your first one above!")
else:
    for i, entry in enumerate(entries):
        ts = entry["created_at"].strftime("%A, %B %d %Y at %H:%M")
        with st.expander(f"{entry['mood']}  \u2014  {ts}", expanded=(i == 0)):
            st.markdown(entry["body"])
            if entry["blockers"]:
                st.markdown("**Blockers:**")
                for blocker in entry["blockers"]:
                    st.markdown(f"- {blocker}")
