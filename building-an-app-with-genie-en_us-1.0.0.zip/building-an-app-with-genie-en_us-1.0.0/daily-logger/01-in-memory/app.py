import streamlit as st
from datetime import datetime

# ---------------------------------------------------------------------------
# In-memory entry store (will be replaced with persistent storage later)
# ---------------------------------------------------------------------------
if "entries" not in st.session_state:
    st.session_state.entries = []

MOODS = ["😊 Great", "🙂 Good", "😐 Okay", "😟 Rough", "😫 Terrible"]

# ---------------------------------------------------------------------------
# Page config
# ---------------------------------------------------------------------------
st.set_page_config(page_title="Daily Logger", page_icon="📓", layout="centered")
st.title("📓 Daily Logger")
st.caption("A personal work-journal app")

# ---------------------------------------------------------------------------
# New entry form
# ---------------------------------------------------------------------------
st.header("New Entry")

with st.form("entry_form", clear_on_submit=True):
    body = st.text_area("What did you work on today?", height=150)
    mood = st.select_slider("Mood", options=MOODS, value="🙂 Good")
    blockers_raw = st.text_input(
        "Blockers (comma-separated, optional)",
        placeholder="e.g. waiting on review, flaky test",
    )
    submitted = st.form_submit_button("Save Entry")

if submitted:
    if not body.strip():
        st.warning("Please write something before saving.")
    else:
        blockers = [
            b.strip() for b in blockers_raw.split(",") if b.strip()
        ]
        entry = {
            "timestamp": datetime.now(),
            "body": body.strip(),
            "mood": mood,
            "blockers": blockers,
        }
        st.session_state.entries.insert(0, entry)  # newest first
        st.success("Entry saved!")

# ---------------------------------------------------------------------------
# History view
# ---------------------------------------------------------------------------
st.divider()
st.header("History")

if not st.session_state.entries:
    st.info("No entries yet \u2014 write your first one above!")
else:
    for i, entry in enumerate(st.session_state.entries):
        ts = entry["timestamp"].strftime("%A, %B %d %Y at %H:%M")
        with st.expander(f"{entry['mood']}  \u2014  {ts}", expanded=(i == 0)):
            st.markdown(entry["body"])
            if entry["blockers"]:
                st.markdown("**Blockers:**")
                for blocker in entry["blockers"]:
                    st.markdown(f"- {blocker}")
