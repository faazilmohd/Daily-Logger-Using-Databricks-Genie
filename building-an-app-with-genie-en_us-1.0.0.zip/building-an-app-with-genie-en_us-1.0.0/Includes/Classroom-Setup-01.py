# Databricks notebook source
# MAGIC %run ./Classroom-Setup-Common

# COMMAND ----------

# DBTITLE 1,ensure app and Lakebase are present
import os

my_app_name,my_app_sp = app_create(False)

my_lakebase_project = lakebase_create(False)
my_lakebase_project_uid = workspace.postgres.get_project(name=f'projects/{my_lakebase_project}').uid
my_lakebase_branch_name = 'production'  # assume this by default
my_lakebase_endpoint_name = 'primary'   # assume by default
my_lakebase_endpoint = f"projects/{my_lakebase_project}/branches/{my_lakebase_branch_name}/endpoints/{my_lakebase_endpoint_name}"

# COMMAND ----------

display_config_values(
    [
        ('App', f'<a href="/apps-v2/app/{my_app_name}/overview" target="_blank">{my_app_name}</a>'),
        ('Lakebase Project', f'<a href="/lakebase/projects/{my_lakebase_project_uid}" target="_blank">{my_lakebase_project}</a>', True),
    ]
)