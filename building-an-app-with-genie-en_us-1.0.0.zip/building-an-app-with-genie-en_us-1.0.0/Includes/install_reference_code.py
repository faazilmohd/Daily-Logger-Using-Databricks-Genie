# Databricks notebook source
# DBTITLE 1,bootstrap
# MAGIC %run ./Classroom-Setup-Common

# COMMAND ----------

# DBTITLE 1,install reference code
dbutils.widgets.text("x", "")
x = dbutils.widgets.get("x")
if not x:
    raise ValueError("Usage: %run ./Includes/install_reference_code $x=\"<name>\"")

sources = {
    'daily-logger-in-memory': {
        'src': 'daily-logger/01-in-memory',
        'dst': home('daily-logger-reference')
    },
    'daily-logger-lakebase': {
        'src': 'daily-logger/02-lakebase/01-generated',
        'dst': home('daily-logger-reference')
    },
    'daily-logger-lakebase-fixed': {
        'src': 'daily-logger/03-per-user',
        'dst': home('daily-logger-reference')
    },
    'quick-poll': {
        'src': 'quick-poll',
        'dst': home('quick-poll-reference')
    },
    'create-lakebase-app-skill': {
        'src': 'create-lakebase-app-skill/02-corrected',
        'dst': home(".assistant/skills/create-lakebase-app")
    }
}

if x not in sources:
    raise ValueError(f"{x} not found in: {list(sources.keys())}")

my_app_source = copy_folder(
    src=sources[x]['src'],
    dst=sources[x]['dst'],
    clean=True
)

display_config_values([
    ('Reference code', f'<a href="#workspace{my_app_source}" target="_blank">{chr(127968)} /{"/".join(my_app_source.split("/")[-1:])}</a>', my_app_source),
])