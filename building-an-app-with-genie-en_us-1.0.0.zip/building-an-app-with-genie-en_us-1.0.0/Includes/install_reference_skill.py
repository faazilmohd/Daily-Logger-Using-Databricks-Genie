# Databricks notebook source
# DBTITLE 1,bootstrap
# MAGIC %run ./Classroom-Setup-Common

# COMMAND ----------

# DBTITLE 1,install reference skill
dst = copy_folder(
    src='create-lakebase-app-skill/02-corrected',
    dst=home(".assistant/skills/create-lakebase-app"),
    clean=True
)

displayHTML(
    f'\u2705 Skill installed in <a href="#workspace{dst}" target="_blank">{dst}</a>'
)