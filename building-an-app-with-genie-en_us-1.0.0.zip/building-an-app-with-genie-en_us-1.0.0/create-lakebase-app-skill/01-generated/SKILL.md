---
name: create-lakebase-app
description: Patterns for scaffolding a new Databricks App backed by a Lakebase Postgres Autoscaling database. Load when creating an app that persists state in Lakebase, or when wiring an existing app to Lakebase for the first time.
---

# Create a Lakebase-Backed Databricks App

This skill encodes the correct, battle-tested patterns for standing up a Databricks App that uses Lakebase Postgres Autoscaling for persistent storage. Follow these rules strictly to avoid ownership, permission, credential, and injection issues.

## 1. Always include a `requirements.txt` with pinned versions

Every Lakebase-backed app MUST have a `requirements.txt` in the app source folder. Pin exact versions to ensure reproducible builds.

Required libraries:

```text
databricks-sdk>=0.55.0
psycopg2-binary>=2.9.10
streamlit>=1.45.0
```

Adjust the framework line (streamlit, flask, dash, gradio) to match the app. Never omit `databricks-sdk` or `psycopg2-binary`.

## 2. Credential generation: use the Lakebase Autoscaling API

Always generate short-lived OAuth tokens via the Databricks SDK `w.postgres` service. Tokens expire after ~1 hour; refresh proactively every 15 minutes.

```python
import os
import time
from databricks.sdk import WorkspaceClient

_token_cache = {"token": None, "refreshed_at": 0}

def _get_token() -> str:
    """Return a Lakebase OAuth token, refreshing every 15 minutes."""
    now = time.time()
    if _token_cache["token"] is None or now - _token_cache["refreshed_at"] > 900:
        w = WorkspaceClient()
        cred = w.postgres.generate_database_credential(
            endpoint=w.postgres.get_endpoint(
                os.environ["LAKEBASE_INSTANCE_NAME"]
            ).name
        )
        _token_cache["token"] = cred.token
        _token_cache["refreshed_at"] = now
    return _token_cache["token"]
```

**Critical:** Always call `_get_token()` when opening a new connection (not once at import time). This ensures expired tokens are never reused.

Do NOT use the legacy `w.database.generate_database_credential()` API. That belongs to Lakebase Provisioned instances and will fail on Autoscaling projects.

## 3. Connection details from environment variables only

Never hardcode hosts, database names, ports, or usernames. Read them from the environment variables that Databricks Apps injects when a Lakebase resource is attached:

| Variable | Source |
| --- | --- |
| `PGHOST` | Injected by the platform when a Lakebase resource is added |
| `PGDATABASE` | Injected by the platform |
| `PGUSER` | Injected by the platform (the app SP's client ID) |
| `PGPORT` | Injected by the platform (default 5432) |
| `LAKEBASE_INSTANCE_NAME` | Defined in `app.yaml` via `valueFrom` on the resource key |

### app.yaml pattern

```yaml
command:
  - streamlit
  - run
  - app.py
  - --server.port
  - "8000"

env:
  - name: STREAMLIT_GATHER_USAGE_STATS
    value: "false"
  - name: LAKEBASE_INSTANCE_NAME
    valueFrom: database
```

The `valueFrom: database` resolves to the Lakebase resource added under the key "database" in the app's resource configuration (set in the UI or via bundle). This gives the app the endpoint resource name needed for `get_endpoint()`.

### Connection helper

```python
import os
import psycopg2

def get_conn():
    """Open a fresh psycopg2 connection with a valid token."""
    return psycopg2.connect(
        host=os.environ["PGHOST"],
        database=os.environ["PGDATABASE"],
        user=os.environ["PGUSER"],
        port=os.environ.get("PGPORT", "5432"),
        password=_get_token(),
        sslmode="require",
    )
```

## 4. App owns its schema and tables — create at runtime, never outside

The app's service principal becomes the owner of any objects it creates. This is the ONLY safe pattern. Pre-creating tables from a notebook or personal role causes ownership mismatches — the app SP cannot ALTER or DROP tables it doesn't own.

**Rules:**
- The app MUST call `CREATE SCHEMA IF NOT EXISTS` and `CREATE TABLE IF NOT EXISTS` on every startup (idempotent bootstrap).
- Never run DDL from a separate notebook, the Lakebase UI, or a personal SQL session for objects the app will manage.
- If a migration is needed (adding columns), use a `DO $BODY$...END $BODY$;` block inside the same bootstrap function so it runs under the app's identity.

```python
def _bootstrap_db():
    conn = get_conn()
    conn.autocommit = True
    with conn.cursor() as cur:
        cur.execute(f"CREATE SCHEMA IF NOT EXISTS {SCHEMA}")
        cur.execute(f"""
            CREATE TABLE IF NOT EXISTS {SCHEMA}.my_table (
                id SERIAL PRIMARY KEY,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                -- add columns here
            )
        """)
    conn.close()

_bootstrap_db()
```

Call `_bootstrap_db()` at module level (top of the file, after function definitions) so it runs once when the app process starts.

## 5. Parameterized SQL only — no string interpolation for values

All user-supplied or dynamic VALUES must use `%s` placeholders with a parameter tuple. Never use f-strings or `.format()` to inject values into SQL.

**Correct:**
```python
cur.execute(
    "INSERT INTO daily_logger.entries (body, mood) VALUES (%s, %s)",
    (body, mood),
)
```

**Wrong — SQL injection risk:**
```python
cur.execute(f"INSERT INTO daily_logger.entries (body) VALUES ('{body}')")
```

Table and schema names are safe to interpolate via f-string (they come from constants, not user input), but values NEVER.

## 6. Scaffold checklist

When creating a new Lakebase-backed app from scratch, produce these files:

| File | Purpose |
| --- | --- |
| `app.yaml` | Command, env vars with `valueFrom: database` |
| `app.py` | App code with bootstrap, token refresh, parameterized queries |
| `requirements.txt` | Pinned deps: `databricks-sdk`, `psycopg2-binary`, framework |

After writing the source, remind the user to:
1. Add a **Lakebase Autoscaling database resource** (key: `database`) to the app via the Apps UI (project, branch, database, permission: "Can connect and create").
2. Deploy with `databricks apps deploy <app-name> --source-code-path /Workspace/Users/<email>/<folder>`.

## 7. Common pitfalls

| Pitfall | Fix |
| --- | --- |
| "must be owner of table" on ALTER | Table was pre-created outside the app. Drop it and let the app recreate, or transfer ownership. |
| Token expired mid-session | Ensure `_get_token()` is called per-connection, not cached at import time. |
| `w.database.generate_database_credential` fails | That’s the Provisioned API. Use `w.postgres.generate_database_credential` for Autoscaling. |
| `LAKEBASE_INSTANCE_NAME` is None | Missing `valueFrom: database` in `app.yaml`, or the Lakebase resource was not added to the app. |
| `$` dollar-quoting lost in f-strings | Python f-strings collapse `$` to `. Use named delimiters: `$BODY$...$BODY. |
