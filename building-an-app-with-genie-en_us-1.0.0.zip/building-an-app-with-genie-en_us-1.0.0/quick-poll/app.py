import os
import time
import streamlit as st
import psycopg2
import psycopg2.extras
from databricks.sdk import WorkspaceClient

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
POLL_QUESTION = "What should we build next?"
POLL_OPTIONS = ["Feature A", "Feature B", "Feature C"]

SCHEMA = "quick_poll"
TABLE = f"{SCHEMA}.votes"

# ---------------------------------------------------------------------------
# Database connection with token refresh (Lakebase Autoscaling API)
# ---------------------------------------------------------------------------
_token_cache = {"token": None, "refreshed_at": 0}


def _get_token() -> str:
    """Return a Lakebase OAuth token, refreshing every 15 minutes."""
    now = time.time()
    if _token_cache["token"] is None or now - _token_cache["refreshed_at"] > 900:
        w = WorkspaceClient()
        cred = w.postgres.generate_database_credential(
            endpoint=w.postgres.get_endpoint(
                os.environ["LAKEBASE_INSTANCE_NAME"]
            ).name
        )
        _token_cache["token"] = cred.token
        _token_cache["refreshed_at"] = now
    return _token_cache["token"]


def get_conn():
    """Open a fresh psycopg2 connection with a valid token."""
    return psycopg2.connect(
        host=os.environ["PGHOST"],
        database=os.environ["PGDATABASE"],
        user=os.environ["PGUSER"],
        port=os.environ.get("PGPORT", "5432"),
        password=_get_token(),
        sslmode="require",
    )


# ---------------------------------------------------------------------------
# Bootstrap: app owns its schema and tables (idempotent)
# ---------------------------------------------------------------------------
def _bootstrap_db():
    conn = get_conn()
    conn.autocommit = True
    with conn.cursor() as cur:
        cur.execute(f"CREATE SCHEMA IF NOT EXISTS {SCHEMA}")
        cur.execute(f"""
            CREATE TABLE IF NOT EXISTS {TABLE} (
                id SERIAL PRIMARY KEY,
                voted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                user_email VARCHAR(255) NOT NULL,
                choice VARCHAR(255) NOT NULL
            )
        """)
    conn.close()


_bootstrap_db()


# ---------------------------------------------------------------------------
# Data access helpers (parameterized SQL only)
# ---------------------------------------------------------------------------
def cast_vote(user_email: str, choice: str):
    conn = get_conn()
    with conn.cursor() as cur:
        cur.execute(
            f"INSERT INTO {TABLE} (user_email, choice) VALUES (%s, %s)",
            (user_email, choice),
        )
    conn.commit()
    conn.close()


def get_results() -> list[dict]:
    """Return vote counts per choice, ordered highest first."""
    conn = get_conn()
    with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute(
            f"SELECT choice, COUNT(*) AS votes FROM {TABLE} GROUP BY choice ORDER BY votes DESC"
        )
        rows = cur.fetchall()
    conn.close()
    return rows


def has_voted(user_email: str) -> bool:
    conn = get_conn()
    with conn.cursor() as cur:
        cur.execute(
            f"SELECT 1 FROM {TABLE} WHERE user_email = %s LIMIT 1",
            (user_email,),
        )
        result = cur.fetchone()
    conn.close()
    return result is not None


# ---------------------------------------------------------------------------
# User identity
# ---------------------------------------------------------------------------
def _get_current_user() -> str:
    headers = st.context.headers
    email = headers.get("X-Forwarded-Email", "") or headers.get("x-forwarded-email", "")
    return email.strip().lower()


# ---------------------------------------------------------------------------
# Streamlit UI
# ---------------------------------------------------------------------------
st.set_page_config(page_title="QuickPoll", page_icon="\U0001f5f3\ufe0f", layout="centered")
st.title("\U0001f5f3\ufe0f QuickPoll")

current_user = _get_current_user()
if not current_user:
    st.error("Unable to identify you. Please access this app through Databricks Apps.")
    st.stop()

st.caption(f"Signed in as **{current_user}**")
st.subheader(POLL_QUESTION)

# --- Voting ---
already_voted = has_voted(current_user)

if already_voted:
    st.info("You have already voted. Thanks!")
else:
    with st.form("vote_form"):
        choice = st.radio("Pick one:", POLL_OPTIONS)
        submitted = st.form_submit_button("Submit Vote")
    if submitted:
        cast_vote(current_user, choice)
        st.success(f"Vote recorded for **{choice}**!")
        st.rerun()

# --- Results ---
st.divider()
st.subheader("Results")

results = get_results()

if not results:
    st.info("No votes yet \u2014 be the first!")
else:
    # Build a dict with all options (show zero-vote options too)
    counts = {opt: 0 for opt in POLL_OPTIONS}
    for row in results:
        if row["choice"] in counts:
            counts[row["choice"]] = row["votes"]

    st.bar_chart(counts, horizontal=True)
    total = sum(counts.values())
    st.caption(f"{total} vote{'s' if total != 1 else ''} cast")
