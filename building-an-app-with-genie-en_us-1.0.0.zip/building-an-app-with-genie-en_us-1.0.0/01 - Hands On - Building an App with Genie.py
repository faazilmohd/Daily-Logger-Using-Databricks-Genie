# Databricks notebook source
# MAGIC %md
# MAGIC ![DB Academy](https://files.training.databricks.com/binder/prod_main/building-an-app-with-genie-en_us-1.0.0/images/20261001T125359Z/Includes/images/databricks_academy_logo.png)

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC # Hands On: Building an App with Genie
# MAGIC
# MAGIC You need an internal app by the end of the day. Something small — a work journal your
# MAGIC team can use to log what they did and what got in the way — but it has to be real: a
# MAGIC working URL people can open, entries that persist, and no infrastructure for you to
# MAGIC babysit.
# MAGIC
# MAGIC You are not going to write it. You are going to **describe** it, and then do the part
# MAGIC that actually requires you: reading what comes back, correcting it, and shipping it.
# MAGIC
# MAGIC **Duration:** 90 minutes — the core sections are taught live in about an hour; the
# MAGIC bonus sections are yours to finish afterward.
# MAGIC
# MAGIC ## Objectives
# MAGIC
# MAGIC In this lab, you will:
# MAGIC - Place **Genie Code** within the Genie family, and use it to scaffold a working Databricks App from a plain-language description
# MAGIC - Attach a Lakebase database to your app as a resource so the app's data survives a restart
# MAGIC - Review generated code before you trust it, and diagnose a failure that a successful deployment does not catch
# MAGIC - Use Genie Code as an **agent** — putting data into your database, not just code into your files
# MAGIC - *(Bonus)* Install and critically review a **Skill** that encodes this lab's lessons, and find the official Databricks skills library
# MAGIC
# MAGIC ## Agenda
# MAGIC
# MAGIC <div style="display: flex; flex-direction: column; gap: 0; margin: 16px 0; border-radius: 12px; overflow: hidden; border: 1px solid #DCE0E2; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;">
# MAGIC   <div style="display: grid; grid-template-columns: 44px 1.4fr 72px 2.5fr; align-items: center; padding: 10px 16px; background: #1B3139; color: #fff; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.08em;">
# MAGIC     <span></span>
# MAGIC     <span>Section</span>
# MAGIC     <span style="text-align: center;">Time</span>
# MAGIC     <span>Activity</span>
# MAGIC   </div>
# MAGIC   <div style="display: grid; grid-template-columns: 44px 1.4fr 72px 2.5fr; align-items: center; padding: 12px 16px; border-bottom: 1px solid #ECEEF0; background: #fff;">
# MAGIC     <div style="width: 28px; height: 28px; border-radius: 6px; background: #FF3621; display: flex; align-items: center; justify-content: center;">
# MAGIC       <span style="color: #fff; font-size: 13px; font-weight: 800;">A</span>
# MAGIC     </div>
# MAGIC     <div style="font-size: 14px; font-weight: 600; color: #1B3139;">Setup</div>
# MAGIC     <div style="text-align: center; font-size: 14px; font-weight: 700; color: #5A6F77;">5 min</div>
# MAGIC     <div style="font-size: 14px; color: #5A6F77;">Connect compute, run classroom setup
# MAGIC       <span style="display: inline-block; background: #E8F5E9; border: 1px solid #A5D6A7; border-radius: 3px; padding: 1px 6px; font-size: 10px; font-weight: 700; color: #2E7D32; margin-left: 8px; vertical-align: middle;">hands-on</span>
# MAGIC     </div>
# MAGIC   </div>
# MAGIC   <div style="display: grid; grid-template-columns: 44px 1.4fr 72px 2.5fr; align-items: center; padding: 12px 16px; border-bottom: 1px solid #ECEEF0; background: #F9FAFB;">
# MAGIC     <div style="width: 28px; height: 28px; border-radius: 6px; background: #FFAB00; display: flex; align-items: center; justify-content: center;">
# MAGIC       <span style="color: #1B3139; font-size: 13px; font-weight: 800;">B</span>
# MAGIC     </div>
# MAGIC     <div style="font-size: 14px; font-weight: 600; color: #1B3139;">Genie Overview</div>
# MAGIC     <div style="text-align: center; font-size: 14px; font-weight: 700; color: #5A6F77;">5 min</div>
# MAGIC     <div style="font-size: 14px; color: #5A6F77;">Where it fits in the Genie family; the surfaces you use
# MAGIC       <span style="display: inline-block; background: #EDF5FB; border: 1px solid #B8D4E8; border-radius: 3px; padding: 1px 6px; font-size: 10px; font-weight: 700; color: #2272B4; margin-left: 8px; vertical-align: middle;">instructor-led</span>
# MAGIC     </div>
# MAGIC   </div>
# MAGIC   <div style="display: grid; grid-template-columns: 44px 1.4fr 72px 2.5fr; align-items: center; padding: 12px 16px; border-bottom: 1px solid #ECEEF0; background: #fff;">
# MAGIC     <div style="width: 28px; height: 28px; border-radius: 6px; background: #2272B4; display: flex; align-items: center; justify-content: center;">
# MAGIC       <span style="color: #fff; font-size: 13px; font-weight: 800;">C</span>
# MAGIC     </div>
# MAGIC     <div style="font-size: 14px; font-weight: 600; color: #1B3139;">Scaffold an App</div>
# MAGIC     <div style="text-align: center; font-size: 14px; font-weight: 700; color: #5A6F77;">20 min</div>
# MAGIC     <div style="font-size: 14px; color: #5A6F77;">Prompt &rarr; review &rarr; deploy a working prototype
# MAGIC       <span style="display: inline-block; background: #EDF5FB; border: 1px solid #B8D4E8; border-radius: 3px; padding: 1px 6px; font-size: 10px; font-weight: 700; color: #2272B4; margin-left: 8px; vertical-align: middle;">instructor-led</span>
# MAGIC     </div>
# MAGIC   </div>
# MAGIC   <div style="display: grid; grid-template-columns: 44px 1.4fr 72px 2.5fr; align-items: center; padding: 12px 16px; border-bottom: 1px solid #ECEEF0; background: #F9FAFB;">
# MAGIC     <div style="width: 28px; height: 28px; border-radius: 6px; background: #1B3139; display: flex; align-items: center; justify-content: center;">
# MAGIC       <span style="color: #fff; font-size: 13px; font-weight: 800;">D</span>
# MAGIC     </div>
# MAGIC     <div style="font-size: 14px; font-weight: 600; color: #1B3139;">Add Persistence</div>
# MAGIC     <div style="text-align: center; font-size: 14px; font-weight: 700; color: #5A6F77;">15 min</div>
# MAGIC     <div style="font-size: 14px; color: #5A6F77;">Wire up Lakebase, meet the platform, get a working version
# MAGIC       <span style="display: inline-block; background: #EDF5FB; border: 1px solid #B8D4E8; border-radius: 3px; padding: 1px 6px; font-size: 10px; font-weight: 700; color: #2272B4; margin-left: 8px; vertical-align: middle;">instructor-led</span>
# MAGIC     </div>
# MAGIC   </div>
# MAGIC   <div style="display: grid; grid-template-columns: 44px 1.4fr 72px 2.5fr; align-items: center; padding: 12px 16px; border-bottom: 1px solid #ECEEF0; background: #fff;">
# MAGIC     <div style="width: 28px; height: 28px; border-radius: 6px; background: #00A972; display: flex; align-items: center; justify-content: center;">
# MAGIC       <span style="color: #fff; font-size: 13px; font-weight: 800;">E</span>
# MAGIC     </div>
# MAGIC     <div style="font-size: 14px; font-weight: 600; color: #1B3139;">Genie Code as an Agent</div>
# MAGIC     <div style="text-align: center; font-size: 14px; font-weight: 700; color: #5A6F77;">10 min</div>
# MAGIC     <div style="font-size: 14px; color: #5A6F77;">Seed your table with data &mdash; no code written
# MAGIC <span style="display: inline-block; background: #EDF5FB; border: 1px solid #B8D4E8; border-radius: 3px; padding: 1px 6px; font-size: 10px; font-weight: 700; color: #2272B4; margin-left: 8px; vertical-align: middle;">instructor-led</span>
# MAGIC     </div>
# MAGIC   </div>
# MAGIC   <div style="display: grid; grid-template-columns: 44px 1.4fr 72px 2.5fr; align-items: center; padding: 12px 16px; border-bottom: 1px solid #ECEEF0; background: #F9FAFB;">
# MAGIC     <div style="width: 28px; height: 28px; border-radius: 6px; background: #5A6F77; display: flex; align-items: center; justify-content: center;">
# MAGIC       <span style="color: #fff; font-size: 13px; font-weight: 800;">F</span>
# MAGIC     </div>
# MAGIC     <div style="font-size: 14px; font-weight: 600; color: #1B3139;">What's Next: Genie App Builder</div>
# MAGIC     <div style="text-align: center; font-size: 14px; font-weight: 700; color: #5A6F77;">5 min</div>
# MAGIC     <div style="font-size: 14px; color: #5A6F77;">A preview of prompt-to-app for business users
# MAGIC       <span style="display: inline-block; background: #EDF5FB; border: 1px solid #B8D4E8; border-radius: 3px; padding: 1px 6px; font-size: 10px; font-weight: 700; color: #2272B4; margin-left: 8px; vertical-align: middle;">instructor-led</span>
# MAGIC     </div>
# MAGIC   </div>
# MAGIC   <div style="display: grid; grid-template-columns: 44px 1.4fr 72px 2.5fr; align-items: center; padding: 12px 16px; border-bottom: 1px solid #ECEEF0; background: #F9FAFB;">
# MAGIC     <div style="width: 28px; height: 28px; border-radius: 6px; background: #8E7CC3; display: flex; align-items: center; justify-content: center;">
# MAGIC       <span style="color: #fff; font-size: 13px; font-weight: 800;">G</span>
# MAGIC     </div>
# MAGIC     <div style="font-size: 14px; font-weight: 600; color: #1B3139;">Stop Repeating the Same Fix</div>
# MAGIC     <div style="text-align: center; font-size: 14px; font-weight: 700; color: #5A6F77;">20 min</div>
# MAGIC     <div style="font-size: 14px; color: #5A6F77;">Install a Skill, review it, scaffold something new with it
# MAGIC       <span style="display: inline-block; background: #FFF4F2; border: 1px solid #FFC9BE; border-radius: 3px; padding: 1px 6px; font-size: 10px; font-weight: 700; color: #C0341A; margin-left: 8px; vertical-align: middle;">bonus</span>
# MAGIC     </div>
# MAGIC   </div>
# MAGIC   <div style="display: grid; grid-template-columns: 44px 1.4fr 72px 2.5fr; align-items: center; padding: 12px 16px;  background: #F9FAFB;">
# MAGIC     <div style="width: 28px; height: 28px; border-radius: 6px; background: #1976d2; display: flex; align-items: center; justify-content: center;">
# MAGIC       <span style="color: #fff; font-size: 13px; font-weight: 800;">H</span>
# MAGIC     </div>
# MAGIC     <div style="font-size: 14px; font-weight: 600; color: #1B3139;">The Databricks Skills Library</div>
# MAGIC     <div style="text-align: center; font-size: 14px; font-weight: 700; color: #5A6F77;">5 min</div>
# MAGIC     <div style="font-size: 14px; color: #5A6F77;">30 official skills, one CLI command
# MAGIC       <span style="display: inline-block; background: #FFF4F2; border: 1px solid #FFC9BE; border-radius: 3px; padding: 1px 6px; font-size: 10px; font-weight: 700; color: #C0341A; margin-left: 8px; vertical-align: middle;">bonus</span>
# MAGIC     </div>
# MAGIC   </div>
# MAGIC </div>
# MAGIC
# MAGIC <div style="border-left: 4px solid #1976d2; background: #e3f2fd; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <strong style="color: #0d47a1;">Live delivery ends after section F</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #0d47a1;">Sections A through F are what we cover together &mdash; about 55 minutes. Sections G and H are marked <strong>Bonus</strong>: everything you need is in this notebook, and the environment stays available afterward.</p>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## A. Setup
# MAGIC
# MAGIC <div style="border: 1px solid #DCE0E2; border-radius: 12px; overflow: hidden; margin: 16px 0;">
# MAGIC   <div style="background: #FF3621; color: #fff; padding: 11px 18px; display: flex; align-items: center; gap: 10px;">
# MAGIC     <svg style="width: 22px; height: 22px;" viewBox="0 0 24 24"><path fill="#fff" d="M22.7 19 13.6 4.27a1.83 1.83 0 0 0-3.13.01L1.3 19a1.83 1.83 0 0 0 1.57 2.76h18.27c1.41 0 2.29-1.55 1.57-2.76M12 18a1 1 0 1 1 0-2 1 1 0 0 1 0 2m1-4h-2v-5h2z"/></svg>
# MAGIC     <strong style="font-size:14pt; letter-spacing: 0.05em; text-transform: uppercase;">Required: Select a compute environment</strong>
# MAGIC   </div>
# MAGIC   <div style="background: #F9F7F4; padding: 18px 22px; color: #1B3139;">
# MAGIC     <p style="margin: 0 0 10px 0; font-size:14pt; line-height: 1.6;"><strong>Before running any cells</strong>, configure the compute:</p>
# MAGIC     <ol style="margin: 0; padding-left: 22px; font-size:14pt; line-height: 1.7;">
# MAGIC       <li><strong>Attach Serverless:</strong> Click the <strong>Connect</strong> drop-down in the top-right corner of this notebook and select <strong>Serverless</strong> (not a personal cluster or shared compute).</li>
# MAGIC       <li><strong>Verify the base environment:</strong> Open the <strong>Environment</strong> panel (sliders icon on the right sidebar) and confirm <strong>Base environment</strong> is set to <strong>Standard v5</strong>.</li>
# MAGIC     </ol>
# MAGIC   </div>
# MAGIC </div>
# MAGIC
# MAGIC <script>
# MAGIC (function() {
# MAGIC   var tags = [
# MAGIC     {text: '\u23f1 5 min'},
# MAGIC     {text: 'hands-on', preset: 'green'},
# MAGIC     {text: 'required', preset: 'red'},
# MAGIC   ];
# MAGIC   var presets = {
# MAGIC     default: 'background:#F9F7F4; border:1px solid #DCE0E2; color:#5A6F77;',
# MAGIC     blue:    'background:#EDF5FB; border:1px solid #B8D4E8; color:#2272B4;',
# MAGIC     red:     'background:#FFF0EE; border:1px solid #FFBDB4; color:#D4321C;',
# MAGIC     green:   'background:#E8F5E9; border:1px solid #A5D6A7; color:#2E7D32;'
# MAGIC   };
# MAGIC   var base = 'display:inline-block; border-radius:4px; padding:2px 8px; font-size:11px; font-weight:700; margin-left:10px; vertical-align:middle;';
# MAGIC   var el = document.currentScript;
# MAGIC   var h2 = null;
# MAGIC   while (el && !h2) {
# MAGIC     h2 = el.querySelector ? el.querySelector('h2') : null;
# MAGIC     if (!h2) el = el.parentElement;
# MAGIC   }
# MAGIC   if (!h2) return;
# MAGIC   tags.forEach(function(tag) {
# MAGIC     if (h2.querySelector('[data-tag="' + tag.text + '"]')) return;
# MAGIC     var span = document.createElement('span');
# MAGIC     span.setAttribute('data-tag', tag.text);
# MAGIC     span.style.cssText = base + (presets[tag.preset || 'default'] || tag.style || presets.default);
# MAGIC     span.textContent = tag.text;
# MAGIC     h2.appendChild(span);
# MAGIC   });
# MAGIC })();
# MAGIC </script>

# COMMAND ----------

# MAGIC %md
# MAGIC ### A1. Run Setup
# MAGIC
# MAGIC The setup cell provisions the two things you will need: an empty **Databricks App**
# MAGIC to deploy into, and a **Lakebase** database instance to store data in. Run it and wait
# MAGIC for the configuration summary before continuing.

# COMMAND ----------

# MAGIC %run ./Includes/Classroom-Setup-01

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### A2. Setup Output Explained
# MAGIC
# MAGIC The cell above produced two resources you will use throughout this demo:
# MAGIC
# MAGIC <div style="display:grid; grid-template-columns:repeat(2, 1fr); gap:12px; margin:18px 0;">
# MAGIC   <div style="border:1px solid #DCE0E2; border-radius:12px; padding:14px 18px; background:#F9F7F4;">
# MAGIC     <div style="font-weight:700; color:#1B3139; margin-bottom:6px;">App</div>
# MAGIC     <div style="color:#5B6B73; font-size:0.93rem;">An empty Databricks App, already created. It has a URL and a service principal, and nothing deployed to it yet. Use the app in the output above rather than creating your own &mdash; workspaces have a limited number of app slots.</div>
# MAGIC   </div>
# MAGIC   <div style="border:1px solid #DCE0E2; border-radius:12px; padding:14px 18px; background:#F9F7F4;">
# MAGIC     <div style="font-weight:700; color:#1B3139; margin-bottom:6px;">Lakebase instance</div>
# MAGIC     <div style="color:#5B6B73; font-size:0.93rem;">A managed Postgres database, provisioned and running. Nothing is connected to it yet &mdash; no schema, no tables, and no link to your app.</div>
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## B. Genie Overview
# MAGIC
# MAGIC "Genie" is a family of AI experiences at Databricks, not one product, and the names are
# MAGIC close enough to be genuinely confusing. Let's take a moment to place them.
# MAGIC
# MAGIC <div style="max-width:1100px;margin:20px 0;">
# MAGIC <table style="border-collapse:collapse;width:100%;font-size:0.94rem;border:1px solid #DCE0E2;border-radius:12px;overflow:hidden;">
# MAGIC   <tr style="background:#EEEDE9;">
# MAGIC     <th style="text-align:left; padding:10px 16px; color:#1B3139; width:22%;">Member</th>
# MAGIC     <th style="text-align:left; padding:10px 16px; color:#1B3139;">What it is for</th>
# MAGIC   </tr>
# MAGIC   <tr><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#1B3139;"><strong>Genie Agents</strong></td><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#5B6B73;">Conversational, governed access to data for end users. Configured by data owners, not coded. (Previously called Genie Spaces.)</td></tr>
# MAGIC   <tr><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#1B3139;"><strong>Genie Code</strong></td><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#5B6B73;">An AI development assistant embedded across the workspace: it writes and edits code, and can act on your workspace and data.</td></tr>
# MAGIC   <tr><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#1B3139;"><strong>Genie One</strong></td><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#5B6B73;">The unified conversational entry point across the platform.</td></tr>
# MAGIC   <tr><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#1B3139;"><strong>Genie Ontology</strong></td><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#5B6B73;">The semantic layer &mdash; the business meaning that makes the rest of it accurate.</td></tr>
# MAGIC </table>
# MAGIC </div>
# MAGIC
# MAGIC <script>
# MAGIC (function() {
# MAGIC   var tags = [
# MAGIC     {text: '\u23f1 5 min'},
# MAGIC     {text: 'instructor-led', preset: 'blue'},
# MAGIC   ];
# MAGIC   var presets = {
# MAGIC     default: 'background:#F9F7F4; border:1px solid #DCE0E2; color:#5A6F77;',
# MAGIC     blue:    'background:#EDF5FB; border:1px solid #B8D4E8; color:#2272B4;',
# MAGIC     red:     'background:#FFF0EE; border:1px solid #FFBDB4; color:#D4321C;',
# MAGIC     green:   'background:#E8F5E9; border:1px solid #A5D6A7; color:#2E7D32;'
# MAGIC   };
# MAGIC   var base = 'display:inline-block; border-radius:4px; padding:2px 8px; font-size:11px; font-weight:700; margin-left:10px; vertical-align:middle;';
# MAGIC   var el = document.currentScript;
# MAGIC   var h2 = null;
# MAGIC   while (el && !h2) {
# MAGIC     h2 = el.querySelector ? el.querySelector('h2') : null;
# MAGIC     if (!h2) el = el.parentElement;
# MAGIC   }
# MAGIC   if (!h2) return;
# MAGIC   tags.forEach(function(tag) {
# MAGIC     if (h2.querySelector('[data-tag="' + tag.text + '"]')) return;
# MAGIC     var span = document.createElement('span');
# MAGIC     span.setAttribute('data-tag', tag.text);
# MAGIC     span.style.cssText = base + (presets[tag.preset || 'default'] || tag.style || presets.default);
# MAGIC     span.textContent = tag.text;
# MAGIC     h2.appendChild(span);
# MAGIC   });
# MAGIC })();
# MAGIC </script>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### B1. Meet Genie Code
# MAGIC
# MAGIC Unlike Genie Agents, which allows you to query data using plain language, Genie Code
# MAGIC interacts with your entire workspace and data estate, builds software, and can answer general questions.
# MAGIC
# MAGIC A Genie Agent is something you might ship *inside* an application;
# MAGIC Genie Code is what helps you write that application.
# MAGIC
# MAGIC Genie Code [[AWS](https://docs.databricks.com/aws/en/genie-code/) |
# MAGIC [Azure](https://learn.microsoft.com/en-us/azure/databricks/genie-code/) |
# MAGIC [GCP](https://docs.databricks.com/gcp/en/genie-code/)] is not a single window. The
# MAGIC surface you reach for depends on the size of the task.
# MAGIC
# MAGIC <div style="display:grid; grid-template-columns:repeat(2, 1fr); gap:12px; margin:18px 0;">
# MAGIC   <div style="border:1px solid #DCE0E2; border-radius:12px; padding:14px 18px; background:#F9F7F4;">
# MAGIC     <div style="font-weight:700; color:#1B3139; margin-bottom:6px;">Chat</div>
# MAGIC     <div style="color:#5B6B73; font-size:0.93rem;">A conversation with workspace context. Whole files and multi-file changes. This is what we use today.</div>
# MAGIC   </div>
# MAGIC   <div style="border:1px solid #DCE0E2; border-radius:12px; padding:14px 18px; background:#F9F7F4;">
# MAGIC     <div style="font-weight:700; color:#1B3139; margin-bottom:6px;">Inline assistance</div>
# MAGIC     <div style="color:#5B6B73; font-size:0.93rem;">Editing in place, inside a file. Best for small, local changes where describing the edit takes longer than pointing at it.</div>
# MAGIC   </div>
# MAGIC   <div style="border:1px solid #DCE0E2; border-radius:12px; padding:14px 18px; background:#F9F7F4;">
# MAGIC     <div style="font-weight:700; color:#1B3139; margin-bottom:6px;">Custom instructions</div>
# MAGIC     <div style="color:#5B6B73; font-size:0.93rem;">Standing guidance applied to every request, so you stop repeating your preferences in each prompt.</div>
# MAGIC   </div>
# MAGIC   <div style="border:1px solid #DCE0E2; border-radius:12px; padding:14px 18px; background:#F9F7F4;">
# MAGIC     <div style="font-weight:700; color:#1B3139; margin-bottom:6px;">Skills</div>
# MAGIC     <div style="color:#5B6B73; font-size:0.93rem;">Reusable, named instructions for a specific kind of task. Section G, and the reason this lab has a bonus section.</div>
# MAGIC   </div>
# MAGIC </div>
# MAGIC
# MAGIC <div style="border-left: 4px solid #1976d2; background: #e3f2fd; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <strong style="color: #0d47a1;">Genie Code is an agent, not just a code generator</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #0d47a1;">Genie Code can read your files, inspect your workspace, run things, and operate on your data. "Build me an app that does this" and "Explain the relationship between these tables" are both requests it can carry out.</p>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## C. Scaffold an App
# MAGIC
# MAGIC Today, we are building a personal work-journal app. Users write a daily entry — a free-text body, a mood indicator, and an optional list of blockers — and browse their history, newest first.
# MAGIC
# MAGIC <div style="border-left: 4px solid #1976d2; background: #e3f2fd; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <strong style="color: #0d47a1;">About the Reference Code</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #0d47a1;">Running the following cell will copy <strong>reference code</strong> to a separate subfolder within your home folder. The reference code contains captured Genie Code output and provides a consistent baseline representative of the output you can expect. When you run the prompts, your output may look different from the reference. This is expected; models seldom generate identical output, even when given the same prompt and context.</p>
# MAGIC <p style="margin: 8px 0 0 0; color: #0d47a1;">The reference code can also be used when time is at a premium or if you are struggling with the prompts.</p>
# MAGIC </div>
# MAGIC
# MAGIC <script>
# MAGIC (function() {
# MAGIC   var tags = [
# MAGIC     {text: '\u23f1 20 min'},
# MAGIC     {text: 'instructor-led', preset: 'blue'},
# MAGIC   ];
# MAGIC   var presets = {
# MAGIC     default: 'background:#F9F7F4; border:1px solid #DCE0E2; color:#5A6F77;',
# MAGIC     blue:    'background:#EDF5FB; border:1px solid #B8D4E8; color:#2272B4;',
# MAGIC     red:     'background:#FFF0EE; border:1px solid #FFBDB4; color:#D4321C;',
# MAGIC     green:   'background:#E8F5E9; border:1px solid #A5D6A7; color:#2E7D32;'
# MAGIC   };
# MAGIC   var base = 'display:inline-block; border-radius:4px; padding:2px 8px; font-size:11px; font-weight:700; margin-left:10px; vertical-align:middle;';
# MAGIC   var el = document.currentScript;
# MAGIC   var h2 = null;
# MAGIC   while (el && !h2) {
# MAGIC     h2 = el.querySelector ? el.querySelector('h2') : null;
# MAGIC     if (!h2) el = el.parentElement;
# MAGIC   }
# MAGIC   if (!h2) return;
# MAGIC   tags.forEach(function(tag) {
# MAGIC     if (h2.querySelector('[data-tag="' + tag.text + '"]')) return;
# MAGIC     var span = document.createElement('span');
# MAGIC     span.setAttribute('data-tag', tag.text);
# MAGIC     span.style.cssText = base + (presets[tag.preset || 'default'] || tag.style || presets.default);
# MAGIC     span.textContent = tag.text;
# MAGIC     h2.appendChild(span);
# MAGIC   });
# MAGIC })();
# MAGIC </script>

# COMMAND ----------

# MAGIC %run ./Includes/install_reference_code $x="daily-logger-in-memory"

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### C1. The Prompt
# MAGIC
# MAGIC A good prompt does more than describe the outcome you want: it sets the boundaries the assistant will work within and reduces the number of implementation decisions it has to make on your behalf. In AI-assisted development, those unstated decisions matter. The assistant will still produce something when details are missing, but the choices it makes may not match your architecture, constraints, or expectations. A few extra moments spent making the request precise can save a much longer round of review and rework later.
# MAGIC
# MAGIC We are also going to build this in **two steps** — a working prototype first, then persistence. Each step stays small enough to actually review, and when something breaks you know which change broke it.
# MAGIC
# MAGIC Before running the prompt below, read it carefully:
# MAGIC
# MAGIC <div class="code-card">
# MAGIC   <div class="code-card-header">
# MAGIC     <span class="code-card-lang">Plain Language</span>
# MAGIC     <button class="code-card-copy" onclick="copyCode(this)">
# MAGIC       <svg class="copy-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
# MAGIC         <rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/>
# MAGIC       </svg>
# MAGIC       <svg class="check-icon" style="display:none" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
# MAGIC         <polyline points="20 6 9 17 4 12"/>
# MAGIC       </svg>
# MAGIC       <span class="copy-label">Copy</span>
# MAGIC     </button>
# MAGIC   </div>
# MAGIC   <div id="code1" class="code-card-body"></div>
# MAGIC </div>
# MAGIC
# MAGIC <div style="max-width:1050px;margin:20px 0;">
# MAGIC <table style="border-collapse:collapse;width:100%;font-size:0.94rem;border:1px solid #DCE0E2;border-radius:12px;overflow:hidden;">
# MAGIC   <tr style="background:#EEEDE9;">
# MAGIC     <th style="text-align:left;padding:10px 16px;color:#1B3139;width:20%;">Element</th>
# MAGIC     <th style="text-align:left;padding:10px 16px;color:#1B3139;">In this prompt</th>
# MAGIC   </tr>
# MAGIC   <tr><td style="padding:10px 16px;border-top:1px solid #DCE0E2;color:#1B3139;"><strong>Purpose</strong></td><td style="padding:10px 16px;border-top:1px solid #DCE0E2;color:#5B6B73;">"A personal work-journal app"</td></tr>
# MAGIC   <tr><td style="padding:10px 16px;border-top:1px solid #DCE0E2;color:#1B3139;"><strong>Data</strong></td><td style="padding:10px 16px;border-top:1px solid #DCE0E2;color:#5B6B73;">Body, mood indicator, optional list of blockers</td></tr>
# MAGIC   <tr><td style="padding:10px 16px;border-top:1px solid #DCE0E2;color:#1B3139;"><strong>Interaction</strong></td><td style="padding:10px 16px;border-top:1px solid #DCE0E2;color:#5B6B73;">Write an entry; browse history, newest first</td></tr>
# MAGIC   <tr><td style="padding:10px 16px;border-top:1px solid #DCE0E2;color:#1B3139;"><strong>Constraints</strong></td><td style="padding:10px 16px;border-top:1px solid #DCE0E2;color:#5B6B73;">In memory only; a named folder; do not deploy</td></tr>
# MAGIC   <tr><td style="padding:10px 16px;border-top:1px solid #DCE0E2;color:#1B3139;"><strong>Done</strong></td><td style="padding:10px 16px;border-top:1px solid #DCE0E2;color:#5B6B73;">Implied prototype — and notice this is the weakest of the five here</td></tr>
# MAGIC </table>
# MAGIC </div>
# MAGIC <style>
# MAGIC   .code-card {
# MAGIC     font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
# MAGIC     border: 1px solid #DCE0E2;
# MAGIC     border-radius: 0.5rem;
# MAGIC     overflow: hidden;
# MAGIC     background: #F9F7F4;
# MAGIC     max-width: calc(100% - 16px);
# MAGIC     margin: 0.25rem 0;
# MAGIC   }
# MAGIC   .code-card-header {
# MAGIC     display: flex;
# MAGIC     align-items: center;
# MAGIC     justify-content: space-between;
# MAGIC     padding: 0.4rem 0.75rem;
# MAGIC     background: #EEEDE9;
# MAGIC     border-bottom: 1px solid #DCE0E2;
# MAGIC   }
# MAGIC   .code-card-lang {
# MAGIC     font-size: 0.7rem;
# MAGIC     font-weight: 600;
# MAGIC     text-transform: uppercase;
# MAGIC     letter-spacing: 0.1em;
# MAGIC     color: #5A6F77;
# MAGIC   }
# MAGIC   .code-card-copy {
# MAGIC     display: inline-flex;
# MAGIC     align-items: center;
# MAGIC     gap: 0.3rem;
# MAGIC     background: none;
# MAGIC     border: none;
# MAGIC     color: #5A6F77;
# MAGIC     cursor: pointer;
# MAGIC     padding: 0.2rem 0.4rem;
# MAGIC     border-radius: 0.25rem;
# MAGIC     font-size: 0.7rem;
# MAGIC     font-weight: 500;
# MAGIC     transition: color 0.15s, background 0.15s;
# MAGIC   }
# MAGIC   .code-card-copy:hover {
# MAGIC     color: #1B3139;
# MAGIC     background: rgba(0,0,0,0.05);
# MAGIC   }
# MAGIC   .code-card-copy.copied {
# MAGIC     color: #2272B4;
# MAGIC   }
# MAGIC   .code-card-copy svg {
# MAGIC     width: 14px;
# MAGIC     height: 14px;
# MAGIC   }
# MAGIC   .code-card-body {
# MAGIC     margin: 0;
# MAGIC     padding: 1rem;
# MAGIC     overflow-x: auto;
# MAGIC     font-family: 'SF Mono', 'Cascadia Code', 'Fira Code', Consolas, monospace;
# MAGIC     font-size: 0.82rem;
# MAGIC     line-height: 1.55;
# MAGIC     color: #1B3139;
# MAGIC     white-space: pre-wrap;
# MAGIC     word-break: break-word;
# MAGIC   }
# MAGIC </style>
# MAGIC <script>
# MAGIC function copyCode(btn) {
# MAGIC   var code = btn.closest('.code-card').querySelector('.code-card-body').textContent;
# MAGIC   var ta = document.createElement('textarea');
# MAGIC   ta.value = code; ta.style.position='fixed'; ta.style.opacity='0';
# MAGIC   document.body.appendChild(ta); ta.select();
# MAGIC   var ok=false; try { ok = document.execCommand('copy'); } catch(e) {}
# MAGIC   document.body.removeChild(ta);
# MAGIC   if (ok) {
# MAGIC     var l=btn.querySelector('.copy-label'), c=btn.querySelector('.copy-icon'), k=btn.querySelector('.check-icon');
# MAGIC     c.style.display='none'; k.style.display=''; l.textContent='Copied!'; btn.classList.add('copied');
# MAGIC     setTimeout(function(){ c.style.display=''; k.style.display='none'; l.textContent='Copy'; btn.classList.remove('copied'); }, 2000);
# MAGIC   }
# MAGIC }
# MAGIC document.getElementById('code1').textContent = [
# MAGIC   'Please write a Databricks App called "Daily Logger" - a personal work-journal app.',
# MAGIC   '',
# MAGIC   'Users can:',
# MAGIC   '- write a daily entry with a free-text body, a mood indicator, and an optional list of blockers',
# MAGIC   '- browse a history of their past entries, newest first',
# MAGIC   '',
# MAGIC   'For now, store entries in memory only - do NOT wire up any database yet;',
# MAGIC   'I\'ll add persistent storage as a separate step.',
# MAGIC   '',
# MAGIC   'Write the app source into a folder named "daily-logger" in my user home folder.',
# MAGIC   'Do not create or deploy the app; I\'ll deploy the source to an existing app myself.'
# MAGIC ].join('\n');
# MAGIC </script>
# MAGIC
# MAGIC
# MAGIC Open Genie Code and submit it. You should get a couple of files back, quickly.
# MAGIC
# MAGIC Two of those constraints are quietly doing the most work. **"In memory only"** keeps this
# MAGIC first increment small enough to review in one sitting. **"Do not deploy"** is a review
# MAGIC gate: the assistant writes, you read, and only then does anything run.
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### C2. Reviewing the Results
# MAGIC
# MAGIC In this section, we review and test the app. For this section you can review the code Genie Code generated (which will generally differ for each run), or you can explore the reference code for a consistent baseline. If time permits, it'd be ideal to review both and compare. 

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC #### C2.1 Reviewing the Code
# MAGIC
# MAGIC You should have at least two small files: `app.py` and `app.yaml`. Start the review with what is **good**, because if you cannot tell which parts are solid
# MAGIC you cannot tell which parts are not.
# MAGIC
# MAGIC <div style="display:grid; grid-template-columns:repeat(2, 1fr); gap:12px; margin:18px 0;">
# MAGIC   <div style="border:1px solid #DCE0E2; border-radius:12px; padding:14px 18px; background:#F9F7F4;">
# MAGIC     <div style="font-weight:700; color:#1B3139; margin-bottom:6px;">It respected every constraint</div>
# MAGIC     <div style="color:#5B6B73; font-size:0.93rem;">In memory only, the folder you named, and it did not deploy.</div>
# MAGIC   </div>
# MAGIC   <div style="border:1px solid #DCE0E2; border-radius:12px; padding:14px 18px; background:#F9F7F4;">
# MAGIC     <div style="font-weight:700; color:#1B3139; margin-bottom:6px;">Input validation</div>
# MAGIC     <div style="color:#5B6B73; font-size:0.93rem;">Empty entries are rejected with a warning rather than silently saved. Unprompted, and the sort of thing that is easy to skip.</div>
# MAGIC   </div>
# MAGIC   <div style="border:1px solid #DCE0E2; border-radius:12px; padding:14px 18px; background:#F9F7F4;">
# MAGIC     <div style="font-weight:700; color:#1B3139; margin-bottom:6px;">A sensible interface</div>
# MAGIC     <div style="color:#5B6B73; font-size:0.93rem;">A form that clears on submit, a mood slider, collapsible history with the newest entry expanded. None of those details were specified.</div>
# MAGIC   </div>
# MAGIC   <div style="border:1px solid #DCE0E2; border-radius:12px; padding:14px 18px; background:#F9F7F4;">
# MAGIC     <div style="font-weight:700; color:#1B3139; margin-bottom:6px;">Nothing dangerous</div>
# MAGIC     <div style="color:#5B6B73; font-size:0.93rem;">No injection surface, no over-broad permissions, no credentials in the source. Partly because the app is small &mdash; but the review still comes back clean.</div>
# MAGIC   </div>
# MAGIC </div>
# MAGIC
# MAGIC Now the more interesting question: **what did it decide that you never specified?**
# MAGIC
# MAGIC <div style="max-width:1050px;margin:20px 0;">
# MAGIC <table style="border-collapse:collapse;width:100%;font-size:0.94rem;border:1px solid #DCE0E2;border-radius:12px;overflow:hidden;">
# MAGIC   <tr style="background:#EEEDE9;">
# MAGIC     <th style="text-align:left; padding:10px 16px; color:#1B3139; width:28%;">Unspecified</th>
# MAGIC     <th style="text-align:left; padding:10px 16px; color:#1B3139;">What it chose &mdash; check yours</th>
# MAGIC   </tr>
# MAGIC   <tr><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#1B3139;">The framework</td><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#5B6B73;">Streamlit or Gradio are both reasonable choices, but if you had wanted something specific, nothing in the prompt said so.</td></tr>
# MAGIC   <tr><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#1B3139;">What a "mood indicator" is</td><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#5B6B73;">Slider? Buttons? Both options are not "wrong".</td></tr>
# MAGIC   <tr><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#1B3139;">Whether anyone else exists</td><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#5B6B73;">The prompt said "users," but never said <em>multi</em>-user &mdash; so there is probably no concept of a user at all.</td></tr>
# MAGIC   <tr><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#1B3139;">Where the timestamp comes from</td><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#5B6B73;">"Newest first" implies a timestamp. Look for <code>datetime.now()</code> &mdash; local time, no timezone attached. Fine today; flag it.</td></tr>
# MAGIC </table>
# MAGIC </div>
# MAGIC
# MAGIC <div style="border-left: 4px solid #1976d2; background: #e3f2fd; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <strong style="color: #0d47a1;">None of these are bugs</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #0d47a1;">The app works. Every one of them is a decision the model made, because your prompt did not cover it. Sometimes we get pleasantly surprised; sometimes not.</p>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC #### C2.2 Test the App
# MAGIC
# MAGIC Deploy the generated source to your app, then open the app URL.
# MAGIC
# MAGIC 1. Go to your app page using the link in the setup cell output.
# MAGIC 1. Click **Deploy**.
# MAGIC 1. In the **Create deployment** dialog, specify the **Source code path** as follows:
# MAGIC    - **If using the generated source:** navigate to the `daily-logger` subfolder in your home folder, where Genie Code was instructed to write the code
# MAGIC    - **If using the reference code:** copy and paste the **Reference code:** value, found in the cell output at the beginning of this section
# MAGIC 1. Wait for the deployment to report success, then open the app URL.
# MAGIC
# MAGIC Write an entry. Write another. The history list fills in, newest first, with the mood you picked.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC #### C2.3 Test Persistence
# MAGIC
# MAGIC With some entries added, try refreshing the page. Your entries vanished.
# MAGIC
# MAGIC This is not wrong. Recall that we asked for an in-memory store and that's exactly what we got. Entries live in the app's session state, which means they do not survive a refresh, a restart, or a redeploy. This is standard Databricks Apps behavior.
# MAGIC
# MAGIC <div style="border-left: 4px solid #FF3621; background: #FFF4F2; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <strong style="color: #1B3139;">This is a seam, not a defect</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #1B3139;">The application does everything the prompt asked for and is useless for its actual purpose, because a journal you cannot come back to is not a journal. Closing that gap is the next section &mdash; and it is where the work stops being about describing an app and starts being about the platform it runs on.</p>
# MAGIC </div>
# MAGIC
# MAGIC Before moving on, notice what that cost: **one paragraph of plain English and about a
# MAGIC minute.** Keep it as your baseline. The next step is a different kind of work.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## D. Add Persistence
# MAGIC
# MAGIC <script>
# MAGIC (function() {
# MAGIC   var tags = [
# MAGIC     {text: '\u23f1 15 min'},
# MAGIC     {text: 'instructor-led', preset: 'blue'},
# MAGIC   ];
# MAGIC   var presets = {
# MAGIC     default: 'background:#F9F7F4; border:1px solid #DCE0E2; color:#5A6F77;',
# MAGIC     blue:    'background:#EDF5FB; border:1px solid #B8D4E8; color:#2272B4;',
# MAGIC     red:     'background:#FFF0EE; border:1px solid #FFBDB4; color:#D4321C;',
# MAGIC     green:   'background:#E8F5E9; border:1px solid #A5D6A7; color:#2E7D32;'
# MAGIC   };
# MAGIC   var base = 'display:inline-block; border-radius:4px; padding:2px 8px; font-size:11px; font-weight:700; margin-left:10px; vertical-align:middle;';
# MAGIC   var el = document.currentScript;
# MAGIC   var h2 = null;
# MAGIC   while (el && !h2) {
# MAGIC     h2 = el.querySelector ? el.querySelector('h2') : null;
# MAGIC     if (!h2) el = el.parentElement;
# MAGIC   }
# MAGIC   if (!h2) return;
# MAGIC   tags.forEach(function(tag) {
# MAGIC     if (h2.querySelector('[data-tag="' + tag.text + '"]')) return;
# MAGIC     var span = document.createElement('span');
# MAGIC     span.setAttribute('data-tag', tag.text);
# MAGIC     span.style.cssText = base + (presets[tag.preset || 'default'] || tag.style || presets.default);
# MAGIC     span.textContent = tag.text;
# MAGIC     h2.appendChild(span);
# MAGIC   });
# MAGIC })();
# MAGIC </script>
# MAGIC
# MAGIC You just watched your entries disappear on a page refresh. This is the gap between a working prototype and something you'd actually use; a journal that forgets is not really a journal.
# MAGIC
# MAGIC In this section we close that gap by wiring the app to a durable store, so entries survive refreshes, restarts and redeploys.
# MAGIC
# MAGIC <div style="border-left: 4px solid #1976d2; background: #e3f2fd; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <strong style="color: #0d47a1;">Update the Reference Code</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #0d47a1;">Run the following cell to update the reference code with Lakebase integration.</p>
# MAGIC </div>

# COMMAND ----------

# MAGIC %run ./Includes/install_reference_code $x="daily-logger-lakebase"

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### D1. Why this App Needs a Lakebase
# MAGIC
# MAGIC Journal entries arrive one at a time, as somebody clicks a button, and each one has to be
# MAGIC readable immediately afterward. That is a *transactional* access pattern — many small
# MAGIC writes and reads, each needing to be correct right now. It is what **Lakebase**, the
# MAGIC managed Postgres in your workspace, is built for.
# MAGIC
# MAGIC A Delta table in Unity Catalog would work, but it is not the best tool for this access
# MAGIC pattern. Delta is optimized for the opposite thing: scanning a lot of data at once rather than writing one row on a button click.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### D2. The Prompt
# MAGIC
# MAGIC One change, building on something that already works.
# MAGIC
# MAGIC <div class="code-card">
# MAGIC   <div class="code-card-header">
# MAGIC     <span class="code-card-lang">Plain Language</span>
# MAGIC     <button class="code-card-copy" onclick="copyCode(this)">
# MAGIC       <svg class="copy-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
# MAGIC         <rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/>
# MAGIC       </svg>
# MAGIC       <svg class="check-icon" style="display:none" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
# MAGIC         <polyline points="20 6 9 17 4 12"/>
# MAGIC       </svg>
# MAGIC       <span class="copy-label">Copy</span>
# MAGIC     </button>
# MAGIC   </div>
# MAGIC   <div id="code2" class="code-card-body"></div>
# MAGIC </div>
# MAGIC
# MAGIC <div style="max-width:1050px;margin:20px 0;">
# MAGIC <table style="border-collapse:collapse;width:100%;font-size:0.94rem;border:1px solid #DCE0E2;border-radius:12px;overflow:hidden;">
# MAGIC   <tr style="background:#EEEDE9;">
# MAGIC     <th style="text-align:left;padding:10px 16px;color:#1B3139;width:20%;">Element</th>
# MAGIC     <th style="text-align:left;padding:10px 16px;color:#1B3139;">In this prompt</th>
# MAGIC   </tr>
# MAGIC   <tr><td style="padding:10px 16px;border-top:1px solid #DCE0E2;color:#1B3139;"><strong>Purpose</strong></td><td style="padding:10px 16px;border-top:1px solid #DCE0E2;color:#5B6B73;">"A personal work-journal app"</td></tr>
# MAGIC   <tr><td style="padding:10px 16px;border-top:1px solid #DCE0E2;color:#1B3139;"><strong>Data</strong></td><td style="padding:10px 16px;border-top:1px solid #DCE0E2;color:#5B6B73;">Body, mood indicator, optional list of blockers</td></tr>
# MAGIC   <tr><td style="padding:10px 16px;border-top:1px solid #DCE0E2;color:#1B3139;"><strong>Interaction</strong></td><td style="padding:10px 16px;border-top:1px solid #DCE0E2;color:#5B6B73;">Write an entry; browse history, newest first</td></tr>
# MAGIC   <tr><td style="padding:10px 16px;border-top:1px solid #DCE0E2;color:#1B3139;"><strong>Constraints</strong></td><td style="padding:10px 16px;border-top:1px solid #DCE0E2;color:#5B6B73;">In memory only; a named folder; do not deploy</td></tr>
# MAGIC   <tr><td style="padding:10px 16px;border-top:1px solid #DCE0E2;color:#1B3139;"><strong>Done</strong></td><td style="padding:10px 16px;border-top:1px solid #DCE0E2;color:#5B6B73;">Implied prototype — and notice this is the weakest of the five here</td></tr>
# MAGIC </table>
# MAGIC </div>
# MAGIC <style>
# MAGIC   .code-card {
# MAGIC     font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
# MAGIC     border: 1px solid #DCE0E2;
# MAGIC     border-radius: 0.5rem;
# MAGIC     overflow: hidden;
# MAGIC     background: #F9F7F4;
# MAGIC     max-width: calc(100% - 16px);
# MAGIC     margin: 0.25rem 0;
# MAGIC   }
# MAGIC   .code-card-header {
# MAGIC     display: flex;
# MAGIC     align-items: center;
# MAGIC     justify-content: space-between;
# MAGIC     padding: 0.4rem 0.75rem;
# MAGIC     background: #EEEDE9;
# MAGIC     border-bottom: 1px solid #DCE0E2;
# MAGIC   }
# MAGIC   .code-card-lang {
# MAGIC     font-size: 0.7rem;
# MAGIC     font-weight: 600;
# MAGIC     text-transform: uppercase;
# MAGIC     letter-spacing: 0.1em;
# MAGIC     color: #5A6F77;
# MAGIC   }
# MAGIC   .code-card-copy {
# MAGIC     display: inline-flex;
# MAGIC     align-items: center;
# MAGIC     gap: 0.3rem;
# MAGIC     background: none;
# MAGIC     border: none;
# MAGIC     color: #5A6F77;
# MAGIC     cursor: pointer;
# MAGIC     padding: 0.2rem 0.4rem;
# MAGIC     border-radius: 0.25rem;
# MAGIC     font-size: 0.7rem;
# MAGIC     font-weight: 500;
# MAGIC     transition: color 0.15s, background 0.15s;
# MAGIC   }
# MAGIC   .code-card-copy:hover {
# MAGIC     color: #1B3139;
# MAGIC     background: rgba(0,0,0,0.05);
# MAGIC   }
# MAGIC   .code-card-copy.copied {
# MAGIC     color: #2272B4;
# MAGIC   }
# MAGIC   .code-card-copy svg {
# MAGIC     width: 14px;
# MAGIC     height: 14px;
# MAGIC   }
# MAGIC   .code-card-body {
# MAGIC     margin: 0;
# MAGIC     padding: 1rem;
# MAGIC     overflow-x: auto;
# MAGIC     font-family: 'SF Mono', 'Cascadia Code', 'Fira Code', Consolas, monospace;
# MAGIC     font-size: 0.82rem;
# MAGIC     line-height: 1.55;
# MAGIC     color: #1B3139;
# MAGIC     white-space: pre-wrap;
# MAGIC     word-break: break-word;
# MAGIC   }
# MAGIC </style>
# MAGIC <script>
# MAGIC function copyCode(btn) {
# MAGIC   var code = btn.closest('.code-card').querySelector('.code-card-body').textContent;
# MAGIC   var ta = document.createElement('textarea');
# MAGIC   ta.value = code; ta.style.position='fixed'; ta.style.opacity='0';
# MAGIC   document.body.appendChild(ta); ta.select();
# MAGIC   var ok=false; try { ok = document.execCommand('copy'); } catch(e) {}
# MAGIC   document.body.removeChild(ta);
# MAGIC   if (ok) {
# MAGIC     var l=btn.querySelector('.copy-label'), c=btn.querySelector('.copy-icon'), k=btn.querySelector('.check-icon');
# MAGIC     c.style.display='none'; k.style.display=''; l.textContent='Copied!'; btn.classList.add('copied');
# MAGIC     setTimeout(function(){ c.style.display=''; k.style.display='none'; l.textContent='Copy'; btn.classList.remove('copied'); }, 2000);
# MAGIC   }
# MAGIC }
# MAGIC document.getElementById('code2').textContent = [
# MAGIC   'Now make the Daily Logger persist entries in a Lakebase database instead of in memory so entries survive restarts.',
# MAGIC   '',
# MAGIC   'Set up whatever is needed on the Lakebase side and wire the app to read and write entries there. Keep the app source in the "daily-logger" folder.',
# MAGIC   '',
# MAGIC   'Don\'t create or deploy the app - I\'ll handle deployment.'
# MAGIC ].join('\n');
# MAGIC </script>
# MAGIC
# MAGIC Notice what this prompt does *not* say: which library to use, how to authenticate, what
# MAGIC the table should look like. Those are implementation details, and the assistant is
# MAGIC generally good at them.
# MAGIC
# MAGIC Submit it, then read what changed.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### D3. Attach Lakebase to Your App
# MAGIC
# MAGIC Your app source reads its connection details from environment variables. Nothing has set
# MAGIC those yet. They get populated when you **attach the Lakebase instance to the app as a
# MAGIC resource** — the link between "an app" and "a database it is allowed to use."
# MAGIC
# MAGIC Let's configure that now:
# MAGIC
# MAGIC 1. Open your app's page and go to the **Configuration** tab (or **Edit** the app).
# MAGIC 1. Under **Resources**, click **Add resource**.
# MAGIC 1. Choose **Database**, then select the Lakebase instance from your setup output.
# MAGIC 1. For **Branch** and **Database**, select `production` and `database_postgres`, respectively.
# MAGIC 1. Set the resource key to `database`, and choose the permission that lets the app **connect and create**.
# MAGIC 1. Save.
# MAGIC
# MAGIC <div style="border-left: 4px solid #FF3621; background: #FFF4F2; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <strong style="color: #1B3139;">Why the resource key matters</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #1B3139;">The app refers to the resource by key using <code>valueFrom: database</code> in <code>app.yaml</code>. Name the key something else and the app will deploy successfully and then fail to connect, because it is asking for a resource that does not exist under that name. Check what key your generated configuration expects and match it.</p>
# MAGIC </div>
# MAGIC
# MAGIC The app also needs to create its own schema and table. That is what the "connect and create" permission grants.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### D4. Review
# MAGIC
# MAGIC Read the changed source before deploying. Once again, start with the wins — and on this
# MAGIC step there are several worth naming:
# MAGIC
# MAGIC <div style="display:grid; grid-template-columns:repeat(2, 1fr); gap:12px; margin:18px 0;">
# MAGIC   <div style="border:1px solid #DCE0E2; border-radius:12px; padding:14px 18px; background:#F9F7F4;">
# MAGIC     <div style="font-weight:700; color:#1B3139; margin-bottom:6px;">No hardcoded credentials</div>
# MAGIC     <div style="color:#5B6B73; font-size:0.93rem;">Authentication uses a short-lived OAuth token requested at runtime and passed as the database password. No secret is written into the source.</div>
# MAGIC   </div>
# MAGIC   <div style="border:1px solid #DCE0E2; border-radius:12px; padding:14px 18px; background:#F9F7F4;">
# MAGIC     <div style="font-weight:700; color:#1B3139; margin-bottom:6px;">Parameterized SQL</div>
# MAGIC     <div style="color:#5B6B73; font-size:0.93rem;">Values are passed as query parameters (<code>%s</code>), never string-formatted into the statement. The injection vector is simply absent.</div>
# MAGIC   </div>
# MAGIC   <div style="border:1px solid #DCE0E2; border-radius:12px; padding:14px 18px; background:#F9F7F4;">
# MAGIC     <div style="font-weight:700; color:#1B3139; margin-bottom:6px;">TLS required</div>
# MAGIC     <div style="color:#5B6B73; font-size:0.93rem;"><code>sslmode=&quot;require&quot;</code> on the connection, unprompted.</div>
# MAGIC   </div>
# MAGIC   <div style="border:1px solid #DCE0E2; border-radius:12px; padding:14px 18px; background:#F9F7F4;">
# MAGIC     <div style="font-weight:700; color:#1B3139; margin-bottom:6px;">Connection details from the environment</div>
# MAGIC     <div style="color:#5B6B73; font-size:0.93rem;">Reads <code>PGHOST</code>, <code>PGDATABASE</code>, <code>PGUSER</code> from the environment rather than hardcoding them &mdash; the correct pattern for an app resource binding.</div>
# MAGIC   </div>
# MAGIC </div>
# MAGIC
# MAGIC There is a fifth win that is easy to miss, and it is the most interesting one.
# MAGIC
# MAGIC In the previous section you flagged `datetime.now()` — a naive local timestamp with no
# MAGIC timezone — as a latent problem. In this version it is **gone**: the assistant moved the
# MAGIC timestamp server-side to a `TIMESTAMPTZ NOT NULL DEFAULT NOW()` column and dropped the
# MAGIC client-side call entirely.
# MAGIC
# MAGIC <div style="border-left: 4px solid #1976d2; background: #e3f2fd; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <strong style="color: #0d47a1;">A lesson worth taking straight</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #0d47a1;">A problem you flagged earlier was resolved by a later iteration making a better design choice. Iteration sometimes fixes things you were worried about. The takeaway is not &quot;trust it to work out&quot; &mdash; it is <em>verify rather than assume</em>, in both directions. Do not go hunting for a bug that is no longer there.</p>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ### D5. Test the App
# MAGIC
# MAGIC Deploy the generated code (or the reference code) and open the app. In any case, you will likely get an error of some sort, rather than a working app.
# MAGIC
# MAGIC In the reference code, we are greeted with:
# MAGIC
# MAGIC ```text
# MAGIC ModuleNotFoundError: No module named 'psycopg2'
# MAGIC ```
# MAGIC
# MAGIC **And yet the deployment succeeded.** That combination is the first lesson: a successful
# MAGIC deploy tells you the platform accepted your source. It does not tell you the app runs.
# MAGIC For any app with dependencies, the first real test is loading the page.
# MAGIC
# MAGIC When deploying generated code, your specific errors may differ, since the output is non-deterministic. But the *class* of problems is generally consistent, and it is worth understanding why.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC #### D5.1 The Root Cause: A Fast-Moving Target
# MAGIC
# MAGIC <div style="display:flex; gap:24px; align-items:center; margin:12px 0; padding-right:16px;">
# MAGIC   <div style="flex:1; min-width:0;">
# MAGIC
# MAGIC Lakebase is a relatively new, rapidly evolving product. Its API methods, authentication patterns, and resource-binding conventions have evolved in the months since the models behind Genie Code were trained. Without any specific contextual information about how Lakebase works *today*, the LLM is forced to infer the integration from things it *does* know: generic Postgres conventions, older Databricks database APIs, and patterns from similar-but-not-identical platforms.
# MAGIC
# MAGIC That inference is remarkably good at getting the *shape* right; parameterized SQL, TLS, OAuth tokens, etc. but it's generally off on the *specifics*; which SDK method issues the credential, what the endpoint name looks like, whether a `requirements.txt` is needed.
# MAGIC
# MAGIC <div style="border-left: 4px solid #1976d2; background: #e3f2fd; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <strong style="color: #0d47a1;">This is not unique to AI</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #0d47a1;">A human engineer writing this integration by hand hits the same wall. Knowing Postgres extremely well does not tell you how <em>this</em> platform hands out credentials, which API generation your instance speaks, or how the instance name reaches your code. That is environment knowledge &mdash; the part that changes fastest and is documented last.</p>
# MAGIC </div>
# MAGIC
# MAGIC   </div>
# MAGIC   <div style="flex:0 0 auto; max-width:320px;">
# MAGIC     <img src="https://files.training.databricks.com/binder/prod_main/building-an-app-with-genie-en_us-1.0.0/images/20261001T125359Z/Includes/images/callout.png" style="width:100%; border-radius:8px; border:1px solid #DCE0E2;">
# MAGIC   </div>
# MAGIC </div>
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #### D5.2 Examples of What Goes Wrong
# MAGIC
# MAGIC The specific failures vary by run, but they cluster into a few categories:
# MAGIC
# MAGIC | Category | What it looks like | Why it happens |
# MAGIC | --- | --- | --- |
# MAGIC | **Missing dependencies** | `ModuleNotFoundError` at page load | No `requirements.txt`, or it omits a library the code imports. Deployment does not import your code — the error surfaces only at runtime. |
# MAGIC | **Wrong credential API** | `AttributeError` or authentication failure | The code calls a credential method from an older SDK generation, or falls back to a generic Postgres password pattern that Lakebase does not support. |
# MAGIC | **Object ownership** | `permission denied for schema` | The assistant pre-creates the schema under *your* identity (the user running the prompt). The app's service principal then cannot access it. |
# MAGIC | **Stale driver choice** | Works, but uses psycopg2 instead of psycopg 3 | psycopg2 dominated Python Postgres for a decade and saturates the training data. Not broken — but not the current version either. |

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC #### D5.3 The Prompting Lesson
# MAGIC
# MAGIC When an unspecified choice matters to you — a driver, a library version, an auth pattern
# MAGIC — **specify it**. Frequency in training data is a reasonable default and a poor
# MAGIC substitute for your requirements.
# MAGIC
# MAGIC And when the integration target is evolving faster than the model's training data, expect to bring platform knowledge to close the gap. That is not a failure of AI-assisted development. It is a description of where an engineer's value concentrates once code generation gets cheap.
# MAGIC
# MAGIC <div style="border-left: 4px solid #1976d2; background: #e3f2fd; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <strong style="color: #0d47a1;">This is where Skills shine</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #0d47a1;">If you find yourself correcting the same platform-specific mistakes on every new app, the answer is not &quot;prompt harder.&quot; It is to give the assistant the context it is missing. That is what Skills are for.</p>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### D6. Testing the Fixed Version
# MAGIC
# MAGIC Time permitting, we could work through and fix all of these issues, but today we are going to do the "cooking-show" approach instead, by advancing to a version that works.
# MAGIC
# MAGIC Run the next cell to apply the fixed version to the reference source, that includes:
# MAGIC - a complete `requirements.txt` with pinned versions
# MAGIC - corrected Lakebase credential handling
# MAGIC - instance name properly threaded in through the resource binding
# MAGIC - per-user isolation

# COMMAND ----------

# MAGIC %run ./Includes/install_reference_code $x="daily-logger-lakebase-fixed"

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC #### D6.1 Deploy
# MAGIC
# MAGIC Prior to deploying the updated code, verify that:
# MAGIC - Genie Code did not create a schema/table for the app in your Lakebase; if so, drop it
# MAGIC - Lakebase is attached to the app as a resource
# MAGIC
# MAGIC Deploy the app using the path in the cell output above, and open the app.
# MAGIC
# MAGIC
# MAGIC <div style="border-left: 4px solid #1976d2; background: #e3f2fd; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <strong style="color: #0d47a1;">Permission errors?</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #0d47a1;">If you are greeted this time with an <code>InsufficientPrivilege</code> error, this is likely due to Genie Code's attempt to be helpful in the previous section. In many instances, it will pre-create your app's schema and table. The issue is that these get created under <em>your</em> identity. The <em>app's</em> identity (its service principal, different from yours) is unable to access or re-create the schema it wants to use.</p>
# MAGIC <p style="margin: 8px 0 0 0; color: #0d47a1;">The solution: drop the schema. In your Lakebase project page (refer to the link in the setup cell output) use the UI to drop the schema, or issue a query like: <code>DROP SCHEMA daily_logger CASCADE</code></p>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC #### D6.2 Test the App
# MAGIC
# MAGIC Write a couple entries. Refresh the page. Entries are accepted, and persist across refreshes. Feel free to observe the table contents using the Lakebase UI.
# MAGIC
# MAGIC <div style="display:grid; grid-template-columns:repeat(2, 1fr); gap:12px; margin:18px 0;">
# MAGIC   <div style="border:1px solid #DCE0E2; border-radius:12px; padding:14px 18px; background:#F9F7F4;">
# MAGIC     <div style="font-weight:700; color:#1B3139; margin-bottom:6px;">Prompting lessons</div>
# MAGIC     <div style="color:#5B6B73; font-size:0.93rem;">Unspecified choices get filled in for you &mdash; the driver, the schema names, single-user versus multi-user. The fix is to state what matters to you. These are about <strong>how you ask</strong>.</div>
# MAGIC   </div>
# MAGIC   <div style="border:1px solid #DCE0E2; border-radius:12px; padding:14px 18px; background:#F9F7F4;">
# MAGIC     <div style="font-weight:700; color:#1B3139; margin-bottom:6px;">Platform-literacy lessons</div>
# MAGIC     <div style="color:#5B6B73; font-size:0.93rem;">How credentials are issued, which API generation your instance speaks, how the instance name reaches your code, who owns the objects. The fix is to understand the platform. These are about <strong>what you know</strong> &mdash; and a human writing this by hand hits every one of them.</div>
# MAGIC   </div>
# MAGIC </div>
# MAGIC
# MAGIC The second pile is not an indictment of AI-assisted development. It is a description of
# MAGIC where an engineer's value concentrates once code generation gets cheap. The assistant
# MAGIC wrote most of this integration in one pass and saved you real time. It could not have
# MAGIC finished it.
# MAGIC
# MAGIC <div style="border-left: 4px solid #1976d2; background: #e3f2fd; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <strong style="color: #0d47a1;">What did that actually cost?</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #0d47a1;">The prototype took one paragraph and about a minute. Making it persist data took a prompt, a resource attachment, and several pieces of platform knowledge that were not in your prompt and not in the model. None of that is unusual &mdash; but notice that <strong>you would pay it again on your next Lakebase-backed app</strong>, and the one after that. <strong>Skills</strong> are all about not paying it twice.</p>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## E. Genie Code as an Agent
# MAGIC
# MAGIC Your journal persists entries now, and it has one or two in it. The history list is nearly empty, so you cannot tell whether it holds up with a
# MAGIC realistic number of entries.
# MAGIC
# MAGIC Let's get some data in there, without writing any code, using Genie Code!
# MAGIC
# MAGIC <script>
# MAGIC (function() {
# MAGIC   var tags = [
# MAGIC     {text: '\u23f1 10 min'},
# MAGIC     {text: 'instructor-led', preset: 'blue'},
# MAGIC   ];
# MAGIC   var presets = {
# MAGIC     default: 'background:#F9F7F4; border:1px solid #DCE0E2; color:#5A6F77;',
# MAGIC     blue:    'background:#EDF5FB; border:1px solid #B8D4E8; color:#2272B4;',
# MAGIC     red:     'background:#FFF0EE; border:1px solid #FFBDB4; color:#D4321C;',
# MAGIC     green:   'background:#E8F5E9; border:1px solid #A5D6A7; color:#2E7D32;'
# MAGIC   };
# MAGIC   var base = 'display:inline-block; border-radius:4px; padding:2px 8px; font-size:11px; font-weight:700; margin-left:10px; vertical-align:middle;';
# MAGIC   var el = document.currentScript;
# MAGIC   var h2 = null;
# MAGIC   while (el && !h2) {
# MAGIC     h2 = el.querySelector ? el.querySelector('h2') : null;
# MAGIC     if (!h2) el = el.parentElement;
# MAGIC   }
# MAGIC   if (!h2) return;
# MAGIC   tags.forEach(function(tag) {
# MAGIC     if (h2.querySelector('[data-tag="' + tag.text + '"]')) return;
# MAGIC     var span = document.createElement('span');
# MAGIC     span.setAttribute('data-tag', tag.text);
# MAGIC     span.style.cssText = base + (presets[tag.preset || 'default'] || tag.style || presets.default);
# MAGIC     span.textContent = tag.text;
# MAGIC     h2.appendChild(span);
# MAGIC   });
# MAGIC })();
# MAGIC </script>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### E1. Asking for Data, Not Code
# MAGIC
# MAGIC Let's devise a prompt that asks Genie Code to put test data directly into your entries table:
# MAGIC - 20 entries
# MAGIC - plausible bodies
# MAGIC - varying moods
# MAGIC - timestamps within the past couple of weeks
# MAGIC - blockers for some
# MAGIC - some entries owned by the caller, random user_email values for others
# MAGIC
# MAGIC <div class="code-card">
# MAGIC   <div class="code-card-header">
# MAGIC     <span class="code-card-lang">Plain Language</span>
# MAGIC     <button class="code-card-copy" onclick="copyCode(this)">
# MAGIC       <svg class="copy-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
# MAGIC         <rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/>
# MAGIC       </svg>
# MAGIC       <svg class="check-icon" style="display:none" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
# MAGIC         <polyline points="20 6 9 17 4 12"/>
# MAGIC       </svg>
# MAGIC       <span class="copy-label">Copy</span>
# MAGIC     </button>
# MAGIC   </div>
# MAGIC   <div id="qp-prompt-seed" class="code-card-body"></div>
# MAGIC </div>
# MAGIC
# MAGIC <style>
# MAGIC   .code-card {
# MAGIC     font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
# MAGIC     border: 1px solid #DCE0E2;
# MAGIC     border-radius: 0.5rem;
# MAGIC     overflow: hidden;
# MAGIC     background: #F9F7F4;
# MAGIC     max-width: calc(100% - 16px);
# MAGIC     margin: 0.25rem 0;
# MAGIC   }
# MAGIC   .code-card-header {
# MAGIC     display: flex;
# MAGIC     align-items: center;
# MAGIC     justify-content: space-between;
# MAGIC     padding: 0.4rem 0.75rem;
# MAGIC     background: #EEEDE9;
# MAGIC     border-bottom: 1px solid #DCE0E2;
# MAGIC   }
# MAGIC   .code-card-lang {
# MAGIC     font-size: 0.7rem;
# MAGIC     font-weight: 600;
# MAGIC     text-transform: uppercase;
# MAGIC     letter-spacing: 0.1em;
# MAGIC     color: #5A6F77;
# MAGIC   }
# MAGIC   .code-card-copy {
# MAGIC     display: inline-flex;
# MAGIC     align-items: center;
# MAGIC     gap: 0.3rem;
# MAGIC     background: none;
# MAGIC     border: none;
# MAGIC     color: #5A6F77;
# MAGIC     cursor: pointer;
# MAGIC     padding: 0.2rem 0.4rem;
# MAGIC     border-radius: 0.25rem;
# MAGIC     font-size: 0.7rem;
# MAGIC     font-weight: 500;
# MAGIC     transition: color 0.15s, background 0.15s;
# MAGIC   }
# MAGIC   .code-card-copy:hover {
# MAGIC     color: #1B3139;
# MAGIC     background: rgba(0,0,0,0.05);
# MAGIC   }
# MAGIC   .code-card-copy.copied {
# MAGIC     color: #2272B4;
# MAGIC   }
# MAGIC   .code-card-copy svg {
# MAGIC     width: 14px;
# MAGIC     height: 14px;
# MAGIC   }
# MAGIC   .code-card-body {
# MAGIC     margin: 0;
# MAGIC     padding: 1rem;
# MAGIC     overflow-x: auto;
# MAGIC     font-family: 'SF Mono', 'Cascadia Code', 'Fira Code', Consolas, monospace;
# MAGIC     font-size: 0.82rem;
# MAGIC     line-height: 1.55;
# MAGIC     color: #1B3139;
# MAGIC     white-space: pre-wrap;
# MAGIC     word-break: break-word;
# MAGIC   }
# MAGIC </style>
# MAGIC <script>
# MAGIC function copyCode(btn) {
# MAGIC   var code = btn.closest('.code-card').querySelector('.code-card-body').textContent;
# MAGIC   var ta = document.createElement('textarea');
# MAGIC   ta.value = code; ta.style.position='fixed'; ta.style.opacity='0';
# MAGIC   document.body.appendChild(ta); ta.select();
# MAGIC   var ok=false; try { ok = document.execCommand('copy'); } catch(e) {}
# MAGIC   document.body.removeChild(ta);
# MAGIC   if (ok) {
# MAGIC     var l=btn.querySelector('.copy-label'), c=btn.querySelector('.copy-icon'), k=btn.querySelector('.check-icon');
# MAGIC     c.style.display='none'; k.style.display=''; l.textContent='Copied!'; btn.classList.add('copied');
# MAGIC     setTimeout(function(){ c.style.display=''; k.style.display='none'; l.textContent='Copy'; btn.classList.remove('copied'); }, 2000);
# MAGIC   }
# MAGIC }
# MAGIC document.getElementById('qp-prompt-seed').textContent = [
# MAGIC   'Please seed the journal entries table in my Daily Logger Lakebase database with 20 fake entries.',
# MAGIC   '',
# MAGIC   '- For the timestamp column, choose random values within the last two weeks',
# MAGIC   '- For the body, write plausible one-or-two-sentence work-journal entries',
# MAGIC   '- Vary the mood values across the available options',
# MAGIC   '- Give roughly a third of them one or two blockers, and leave the rest empty',  
# MAGIC   '- For user_email, use mine for half the entries, and make up different emails for the rest',
# MAGIC ].join('\n');
# MAGIC </script>
# MAGIC
# MAGIC This may take a couple of minutes — the agent has several steps to work through:
# MAGIC finding your database, inspecting a table whose shape it does not yet know,
# MAGIC generating values, and writing rows.
# MAGIC
# MAGIC When it finishes, **reload your app**. No redeploy needed — you changed data, not code.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### E2. Notice What Just Happened
# MAGIC
# MAGIC <div style="border-left: 4px solid #2E7D32; background: #E8F5E9; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <strong style="color: #1B5E20;">The part that may surprise you</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #1B5E20;">Genie Code can do more than just "code". You didn't ask for a script; you asked for <em>data</em>, and the assistant inspected your database, worked out the schema, and wrote rows directly into it.</p>
# MAGIC </div>
# MAGIC
# MAGIC For the record on why this was safe: you own the Lakebase instance, and the operation
# MAGIC inserted rows rather than changing structure — so none of the ownership questions that
# MAGIC come with creating objects apply here.
# MAGIC
# MAGIC <div style="display:grid; grid-template-columns:repeat(2, 1fr); gap:12px; margin:18px 0;">
# MAGIC   <div style="border:1px solid #DCE0E2; border-radius:12px; padding:14px 18px; background:#F9F7F4;">
# MAGIC     <div style="font-weight:700; color:#1B3139; margin-bottom:6px;">What you would have done without Genie Code</div>
# MAGIC     <div style="color:#5B6B73; font-size:0.93rem;">Write a seeding script. Work out the connection handling. Get the schema right by looking it up. Run it. Debug the timestamp format. Fifteen minutes, optimistically.</div>
# MAGIC   </div>
# MAGIC   <div style="border:1px solid #DCE0E2; border-radius:12px; padding:14px 18px; background:#F9F7F4;">
# MAGIC     <div style="font-weight:700; color:#1B3139; margin-bottom:6px;">What you did</div>
# MAGIC     <div style="color:#5B6B73; font-size:0.93rem;">Described the data you wanted, in one paragraph. Went to get coffee. Profited from the results when you got back.</div>
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## F. What's Next: Genie App Builder
# MAGIC
# MAGIC You just built an app by describing it — but you did it as an engineer, in a coding
# MAGIC assistant, with a review step and a deploy step you drove by hand. That is Genie Code's
# MAGIC audience: people who work *on* data and systems.
# MAGIC
# MAGIC **Genie App Builder** is the same idea aimed somewhere else entirely.
# MAGIC
# MAGIC <div style="max-width:1100px;margin:20px 0;">
# MAGIC <table style="border-collapse:collapse;width:100%;font-size:0.94rem;border:1px solid #DCE0E2;border-radius:12px;overflow:hidden;">
# MAGIC   <tr style="background:#EEEDE9;">
# MAGIC     <th style="text-align:left; padding:10px 16px; color:#1B3139; width:20%;"></th>
# MAGIC     <th style="text-align:left; padding:10px 16px; color:#1B3139; width:40%;">Genie Code</th>
# MAGIC     <th style="text-align:left; padding:10px 16px; color:#1B3139;">Genie App Builder</th>
# MAGIC   </tr>
# MAGIC   <tr><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#1B3139;"><strong>Built for</strong></td><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#5B6B73;">Data teams and engineers</td><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#5B6B73;">Business users who want an app</td></tr>
# MAGIC   <tr><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#1B3139;"><strong>Optimized for</strong></td><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#5B6B73;">Automating data and AI workflows; writing and editing code</td><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#5B6B73;">Going from a description to a working application</td></tr>
# MAGIC   <tr><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#1B3139;"><strong>The experience</strong></td><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#5B6B73;">An assistant inside the workspace where you can manage the deployment</td><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#5B6B73;">A managed prompt-to-app environment with live previews</td></tr>
# MAGIC   <tr><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#1B3139;"><strong>In one line</strong></td><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#5B6B73;">Helps you build apps, interact with your environment, and work on data</td><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#5B6B73;">Helps you build apps</td></tr>
# MAGIC </table>
# MAGIC </div>
# MAGIC
# MAGIC The form it takes: a fully managed, enterprise vibe-coding environment where you
# MAGIC describe an app in plain language and see it come together live, with governed access to
# MAGIC real Databricks data. Unity Catalog permissions, access controls, and workspace context
# MAGIC are built in from the start rather than wired up afterward — which is the hard part of
# MAGIC letting non-engineers build internal tools.<br/><br/>
# MAGIC
# MAGIC <img src="https://files.training.databricks.com/binder/prod_main/building-an-app-with-genie-en_us-1.0.0/images/20261001T125359Z/Includes/images/genieappbuilder.png" style="display:block; max-width:calc(100% - 2px); margin:0 auto; border-radius:8px; border:1px solid #DCE0E2;">
# MAGIC
# MAGIC <div style="border-left: 4px solid #1976d2; background: #e3f2fd; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <strong style="color: #0d47a1;">Your role shifts, it does not disappear</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #0d47a1;">When business users can build their own apps, the bottleneck moves. You stop being the person who writes the CRUD screen and start being the person who designs the data model it reads from, sets the permissions it respects, and writes the skills that keep it on the rails. Everything you practiced today &mdash; reviewing generated code, fixing platform integration, encoding knowledge into a skill &mdash; is what that role looks like.</p>
# MAGIC </div>
# MAGIC
# MAGIC <div style="border-left: 4px solid #FF3621; background: #FFF4F2; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <strong style="color: #1B3139;">Preview</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #1B3139;">Genie App Builder is not generally available yet, so access is limited and what is there can change &mdash; this is a heads-up about what is coming and where it fits, not a feature you can go use after this session.</p>
# MAGIC </div>
# MAGIC
# MAGIC <script>
# MAGIC (function() {
# MAGIC   var tags = [
# MAGIC     {text: '\u23f1 5 min'},
# MAGIC     {text: 'instructor-led', preset: 'blue'},
# MAGIC   ];
# MAGIC   var presets = {
# MAGIC     default: 'background:#F9F7F4; border:1px solid #DCE0E2; color:#5A6F77;',
# MAGIC     blue:    'background:#EDF5FB; border:1px solid #B8D4E8; color:#2272B4;',
# MAGIC     red:     'background:#FFF0EE; border:1px solid #FFBDB4; color:#D4321C;',
# MAGIC     green:   'background:#E8F5E9; border:1px solid #A5D6A7; color:#2E7D32;'
# MAGIC   };
# MAGIC   var base = 'display:inline-block; border-radius:4px; padding:2px 8px; font-size:11px; font-weight:700; margin-left:10px; vertical-align:middle;';
# MAGIC   var el = document.currentScript;
# MAGIC   var h2 = null;
# MAGIC   while (el && !h2) {
# MAGIC     h2 = el.querySelector ? el.querySelector('h2') : null;
# MAGIC     if (!h2) el = el.parentElement;
# MAGIC   }
# MAGIC   if (!h2) return;
# MAGIC   tags.forEach(function(tag) {
# MAGIC     if (h2.querySelector('[data-tag="' + tag.text + '"]')) return;
# MAGIC     var span = document.createElement('span');
# MAGIC     span.setAttribute('data-tag', tag.text);
# MAGIC     span.style.cssText = base + (presets[tag.preset || 'default'] || tag.style || presets.default);
# MAGIC     span.textContent = tag.text;
# MAGIC     h2.appendChild(span);
# MAGIC   });
# MAGIC })();
# MAGIC </script>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC <div style="text-align:center; padding:18px; margin:24px 0; background:#F9F7F4; border:1px solid #DCE0E2; border-radius:12px;">
# MAGIC   <div style="font-size:11px; font-weight:800; letter-spacing:0.1em; text-transform:uppercase; color:#5A6F77; margin-bottom:6px;">End of live content</div>
# MAGIC   <div style="color:#1B3139; font-size:14px;">The remaining sections are yours to work through afterward.</div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## G. Stop Repeating the Same Fix
# MAGIC
# MAGIC We hit real problems with Lakebase integration. We explored why, and then advanced to a working version. Here is the annoying part —
# MAGIC **the next app you scaffold using Lakebase can have exactly the same problem.** Nothing you did
# MAGIC taught the assistant anything durable.
# MAGIC
# MAGIC That is what a **Skill** is for, and in this section you are going to install and use one.
# MAGIC
# MAGIC <script>
# MAGIC (function() {
# MAGIC   var tags = [
# MAGIC     {text: '\u23f1 20 min'},
# MAGIC     {text: 'hands-on', preset: 'green'},
# MAGIC     {text: 'bonus', preset: 'red'},
# MAGIC   ];
# MAGIC   var presets = {
# MAGIC     default: 'background:#F9F7F4; border:1px solid #DCE0E2; color:#5A6F77;',
# MAGIC     blue:    'background:#EDF5FB; border:1px solid #B8D4E8; color:#2272B4;',
# MAGIC     red:     'background:#FFF0EE; border:1px solid #FFBDB4; color:#D4321C;',
# MAGIC     green:   'background:#E8F5E9; border:1px solid #A5D6A7; color:#2E7D32;'
# MAGIC   };
# MAGIC   var base = 'display:inline-block; border-radius:4px; padding:2px 8px; font-size:11px; font-weight:700; margin-left:10px; vertical-align:middle;';
# MAGIC   var el = document.currentScript;
# MAGIC   var h2 = null;
# MAGIC   while (el && !h2) {
# MAGIC     h2 = el.querySelector ? el.querySelector('h2') : null;
# MAGIC     if (!h2) el = el.parentElement;
# MAGIC   }
# MAGIC   if (!h2) return;
# MAGIC   tags.forEach(function(tag) {
# MAGIC     if (h2.querySelector('[data-tag="' + tag.text + '"]')) return;
# MAGIC     var span = document.createElement('span');
# MAGIC     span.setAttribute('data-tag', tag.text);
# MAGIC     span.style.cssText = base + (presets[tag.preset || 'default'] || tag.style || presets.default);
# MAGIC     span.textContent = tag.text;
# MAGIC     h2.appendChild(span);
# MAGIC   });
# MAGIC })();
# MAGIC </script>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### G1. What a Skill Is
# MAGIC
# MAGIC A Skill is a named set of instructions Genie Code loads when it recognizes a relevant task. Custom instructions apply to everything you do; a skill applies *when a particular kind of work comes up*, which lets it be far more specific and prescriptive.
# MAGIC
# MAGIC <div style="display:flex;justify-content:center;">
# MAGIC <svg xmlns="http://www.w3.org/2000/svg" width="1178" height="438" viewBox="0 0 1178 438" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif">
# MAGIC   <metadata id="svg-draw-scene"><![CDATA[{"version":1,"width":1178,"height":438,"nodes":[{"x":20,"strokeDasharray":"6 6","y":237,"stroke":"#00A972","text":"","id":"smsord7ml20","dashed":true,"fill":"transparent","h":181,"kind":"rounded","w":1138,"z":-1,"labelFill":"#1B3139","dash":"Long dash"},{"x":324,"labelStyle":"heading-body","y":44,"stroke":"#2272B4","text":"Agent (Genie Code)\nreasons, plans, calls tools","id":"smsorbz302","fill":"#E0EBF5","h":92,"kind":"rounded","w":250},{"x":604,"labelStyle":"heading-body","y":44,"stroke":"#00A972","text":"Skill\nreusable know-how for one task","id":"smsorbz303","fill":"#DBF3EB","h":92,"kind":"rounded","w":250},{"x":884,"labelStyle":"heading-body","y":44,"stroke":"#1B3139","text":"Task done right\nconsistent, repeatable output","id":"smsorbz304","fill":"#DFE2E3","h":92,"kind":"rounded","w":250},{"stroke":"#5A6F77","to":"smsorbz302","id":"cmsorbz305","from":"smsord7ml17","kind":"connector","endHead":"arrow"},{"stroke":"#5A6F77","to":"smsorbz303","id":"cmsorbz306","from":"smsorbz302","kind":"connector","endHead":"arrow"},{"x":240,"size":12,"y":20,"text":"asks for something","id":"tmsorbz307","fill":"#5A6F77","kind":"text","w":84},{"x":520,"size":12,"y":20,"text":"picks the right skill","id":"tmsorbz308","fill":"#5A6F77","kind":"text","w":84},{"x":147,"size":22,"y":250,"text":"Skill","id":"tmsorbz309","fill":"#1B3139","kind":"text"},{"x":44,"labelStyle":"heading-body","y":284,"stroke":"#00A972","text":"Name & description\nwhen this skill should be used — how the agent decides to pick it","id":"smsorbz3011","fill":"#DBF3EB","h":112,"kind":"rounded","w":250},{"x":324,"labelStyle":"heading-body","y":284,"stroke":"#00A972","text":"Instructions\nstep-by-step guidance, rules and style the agent must follow","id":"smsorbz3012","fill":"#DBF3EB","h":112,"kind":"rounded","w":250},{"x":604,"labelStyle":"heading-body","y":284,"stroke":"#00A972","text":"Examples\nworked input/output pairs that show the expected result","id":"smsorbz3013","fill":"#DBF3EB","h":112,"kind":"rounded","w":250},{"x":884,"labelStyle":"heading-body","y":284,"stroke":"#00A972","text":"Resources\nreference snippets, queries or metadata the skill can draw on","id":"smsorbz3014","fill":"#DBF3EB","h":112,"kind":"rounded","w":250},{"stroke":"#00A972","points":[[729,136],[729,186],[590,186],[590,236]],"id":"lmsorbz3015","kind":"line","endHead":"arrow"},{"x":44,"labelStyle":"heading-body","y":44,"stroke":"#FF3621","text":"User prompt\n\"integrate with Lakebase\"","id":"smsord7ml17","fill":"#FFE3E0","labelFill":"#1B3139","h":92,"kind":"rounded","w":250},{"stroke":"#5A6F77","to":"smsorbz304","id":"cmsork51b21","from":"smsorbz303","kind":"connector","endHead":"arrow"},{"x":800,"size":12,"y":20,"text":"includes guidance in context","id":"tmsork51b22","fill":"#5A6F77","kind":"text","w":84}]}]]></metadata>
# MAGIC     <rect x="20" y="237" width="1138" height="181" rx="12" ry="12" fill="transparent" stroke="#00A972" stroke-width="2" stroke-dasharray="16 6"/>
# MAGIC     <rect x="324" y="44" width="250" height="92" rx="12" ry="12" fill="#E0EBF5" stroke="#2272B4" stroke-width="2"/>
# MAGIC     <text x="449" y="90" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif" text-anchor="middle" dominant-baseline="central"><tspan x="449" y="82.5" font-size="16" font-weight="600" fill="#1B3139">Agent (Genie Code)</tspan><tspan x="449" y="100" font-size="12" fill="#5A6F77">reasons, plans, calls tools</tspan></text>
# MAGIC     <rect x="604" y="44" width="250" height="92" rx="12" ry="12" fill="#DBF3EB" stroke="#00A972" stroke-width="2"/>
# MAGIC     <text x="729" y="90" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif" text-anchor="middle" dominant-baseline="central"><tspan x="729" y="82.5" font-size="16" font-weight="600" fill="#1B3139">Skill</tspan><tspan x="729" y="100" font-size="12" fill="#5A6F77">reusable know-how for one task</tspan></text>
# MAGIC     <rect x="884" y="44" width="250" height="92" rx="12" ry="12" fill="#DFE2E3" stroke="#1B3139" stroke-width="2"/>
# MAGIC     <text x="1009" y="90" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif" text-anchor="middle" dominant-baseline="central"><tspan x="1009" y="82.5" font-size="16" font-weight="600" fill="#1B3139">Task done right</tspan><tspan x="1009" y="100" font-size="12" fill="#5A6F77">consistent, repeatable output</tspan></text>
# MAGIC     <line x1="294.0" y1="90.0" x2="319.8" y2="90.0" stroke="#5A6F77" stroke-width="2"/><polygon points="317.0,94.2 324.0,90.0 317.0,85.8" fill="#5A6F77" stroke="#5A6F77" stroke-width="1.5" stroke-linejoin="round"/>
# MAGIC     <line x1="574.0" y1="90.0" x2="599.8" y2="90.0" stroke="#5A6F77" stroke-width="2"/><polygon points="597.0,94.2 604.0,90.0 597.0,85.8" fill="#5A6F77" stroke="#5A6F77" stroke-width="1.5" stroke-linejoin="round"/>
# MAGIC     <text x="240" y="20" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif" font-size="12" fill="#5A6F77" dominant-baseline="text-before-edge">asks for something</text>
# MAGIC     <text x="520" y="20" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif" font-size="12" fill="#5A6F77" dominant-baseline="text-before-edge">picks the right skill</text>
# MAGIC     <text x="147" y="250" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif" font-size="22" fill="#1B3139" dominant-baseline="text-before-edge">Skill</text>
# MAGIC     <rect x="44" y="284" width="250" height="112" rx="12" ry="12" fill="#DBF3EB" stroke="#00A972" stroke-width="2"/>
# MAGIC     <text x="169" y="340" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif" text-anchor="middle" dominant-baseline="central"><tspan x="169" y="325" font-size="16" font-weight="600" fill="#1B3139">Name &amp; description</tspan><tspan x="169" y="342.5" font-size="12" fill="#5A6F77">when this skill should be used — how</tspan><tspan x="169" y="357.5" font-size="12" fill="#5A6F77">the agent decides to pick it</tspan></text>
# MAGIC     <rect x="324" y="284" width="250" height="112" rx="12" ry="12" fill="#DBF3EB" stroke="#00A972" stroke-width="2"/>
# MAGIC     <text x="449" y="340" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif" text-anchor="middle" dominant-baseline="central"><tspan x="449" y="325" font-size="16" font-weight="600" fill="#1B3139">Instructions</tspan><tspan x="449" y="342.5" font-size="12" fill="#5A6F77">step-by-step guidance, rules and</tspan><tspan x="449" y="357.5" font-size="12" fill="#5A6F77">style the agent must follow</tspan></text>
# MAGIC     <rect x="604" y="284" width="250" height="112" rx="12" ry="12" fill="#DBF3EB" stroke="#00A972" stroke-width="2"/>
# MAGIC     <text x="729" y="340" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif" text-anchor="middle" dominant-baseline="central"><tspan x="729" y="325" font-size="16" font-weight="600" fill="#1B3139">Examples</tspan><tspan x="729" y="342.5" font-size="12" fill="#5A6F77">worked input/output pairs that show</tspan><tspan x="729" y="357.5" font-size="12" fill="#5A6F77">the expected result</tspan></text>
# MAGIC     <rect x="884" y="284" width="250" height="112" rx="12" ry="12" fill="#DBF3EB" stroke="#00A972" stroke-width="2"/>
# MAGIC     <text x="1009" y="340" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif" text-anchor="middle" dominant-baseline="central"><tspan x="1009" y="325" font-size="16" font-weight="600" fill="#1B3139">Resources</tspan><tspan x="1009" y="342.5" font-size="12" fill="#5A6F77">reference snippets, queries or</tspan><tspan x="1009" y="357.5" font-size="12" fill="#5A6F77">metadata the skill can draw on</tspan></text>
# MAGIC     <path d="M 729.0 136.0 L 729.0 186.0 L 590.0 186.0 L 590.0 231.8" fill="none" stroke="#00A972" stroke-width="2" stroke-linejoin="round"/><polygon points="585.8,229.0 590.0,236.0 594.2,229.0" fill="#00A972" stroke="#00A972" stroke-width="1.5" stroke-linejoin="round"/>
# MAGIC     <rect x="44" y="44" width="250" height="92" rx="12" ry="12" fill="#FFE3E0" stroke="#FF3621" stroke-width="2"/>
# MAGIC     <text x="169" y="90" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif" text-anchor="middle" dominant-baseline="central"><tspan x="169" y="82.5" font-size="16" font-weight="600" fill="#1B3139">User prompt</tspan><tspan x="169" y="100" font-size="12" fill="#5A6F77">&quot;integrate with Lakebase&quot;</tspan></text>
# MAGIC     <line x1="854.0" y1="90.0" x2="879.8" y2="90.0" stroke="#5A6F77" stroke-width="2"/><polygon points="877.0,94.2 884.0,90.0 877.0,85.8" fill="#5A6F77" stroke="#5A6F77" stroke-width="1.5" stroke-linejoin="round"/>
# MAGIC     <text x="800" y="20" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif" font-size="12" fill="#5A6F77" dominant-baseline="text-before-edge">includes guidance in context</text>
# MAGIC </svg>
# MAGIC </div>
# MAGIC
# MAGIC A skill is a Markdown file with two parts:
# MAGIC
# MAGIC <div style="max-width:1050px;margin:20px 0;">
# MAGIC <table style="border-collapse:collapse;width:100%;font-size:0.94rem;border:1px solid #DCE0E2;border-radius:12px;overflow:hidden;">
# MAGIC   <tr style="background:#EEEDE9;">
# MAGIC     <th style="text-align:left; padding:10px 16px; color:#1B3139; width:26%;">Part</th>
# MAGIC     <th style="text-align:left; padding:10px 16px; color:#1B3139;">What it does</th>
# MAGIC   </tr>
# MAGIC   <tr><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#1B3139;"><strong>Front matter</strong></td><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#5B6B73;">A <code>name</code> and a <code>description</code>. The description is a load trigger &mdash; it tells the assistant <em>when</em> this skill is relevant, so it describes the situation, not just the topic.</td></tr>
# MAGIC   <tr><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#1B3139;"><strong>Body</strong></td><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#5B6B73;">The instructions. Rules, correct and incorrect examples, checklists, known pitfalls.</td></tr>
# MAGIC </table>
# MAGIC </div>
# MAGIC
# MAGIC Genie Code skills follow the [Agent Skills open standard](https://agentskills.io/home).
# MAGIC See the docs for details [[AWS](https://docs.databricks.com/aws/en/genie-code/skills) |
# MAGIC [Azure](https://learn.microsoft.com/en-us/azure/databricks/genie-code/skills) |
# MAGIC [GCP](https://docs.databricks.com/gcp/en/genie-code/skills)].

# COMMAND ----------

# MAGIC %md
# MAGIC ### G2. Install the Skill
# MAGIC
# MAGIC Rather than writing one from scratch, you are going to install a skill that already encodes the lessons from this lab — and then find out what it is worth.
# MAGIC
# MAGIC Run the next cell to install `create-lakebase-app` into your user skills folder.

# COMMAND ----------

# MAGIC %run ./Includes/install_reference_skill

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### G3. Read It Before You Trust It
# MAGIC
# MAGIC Open the installed `SKILL.md` and read it. Do not skip this — it is the most important
# MAGIC five minutes of this section.
# MAGIC
# MAGIC <div style="border-left: 4px solid #FF3621; background: #FFF4F2; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <strong style="color: #1B3139;">A skill is only as good as your review of it</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #1B3139;">This file's entire purpose is preventing mistakes. If it contains one, that mistake propagates into every app built from it &mdash; silently, and with more authority than before, because now it is written down. A skill someone hands you deserves the same scrutiny as code someone hands you.</p>
# MAGIC </div>
# MAGIC
# MAGIC Four things to check. Each one caught a real defect when this material was built:
# MAGIC
# MAGIC <div style="max-width:1100px;margin:20px 0;">
# MAGIC <table style="border-collapse:collapse;width:100%;font-size:0.94rem;border:1px solid #DCE0E2;border-radius:12px;overflow:hidden;">
# MAGIC   <tr style="background:#EEEDE9;">
# MAGIC     <th style="text-align:left; padding:10px 16px; color:#1B3139; width:32%;">Check</th>
# MAGIC     <th style="text-align:left; padding:10px 16px; color:#1B3139;">Why it matters</th>
# MAGIC   </tr>
# MAGIC   <tr><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#1B3139;"><strong>Are versions pinned to what actually works?</strong></td><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#5B6B73;">A <em>minimum</em> version can resolve to something older than the version that fixed the problem &mdash; reintroducing the exact bug the skill exists to prevent. This is the most dangerous failure mode and the easiest to read straight past.</td></tr>
# MAGIC   <tr><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#1B3139;"><strong>Does the prose agree with the examples?</strong></td><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#5B6B73;">If the text says "pin exact versions" and a sample uses a range, the skill contradicts itself &mdash; and the assistant will follow the example.</td></tr>
# MAGIC   <tr><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#1B3139;"><strong>Is every code sample intact?</strong></td><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#5B6B73;">Generated Markdown containing code sometimes garbles on escaping. A corrupted example is worse than a missing one. There is at least one imperfection in this file &mdash; see whether you can find it.</td></tr>
# MAGIC   <tr><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#1B3139;"><strong>Is each rule actionable?</strong></td><td style="padding:10px 16px; border-top:1px solid #DCE0E2; color:#5B6B73;">"Handle credentials properly" is not a rule. "Use this specific API, not that one" is.</td></tr>
# MAGIC </table>
# MAGIC </div>
# MAGIC
# MAGIC <div style="border-left: 4px solid #1976d2; background: #e3f2fd; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <strong style="color: #0d47a1;">Why you are reviewing instead of writing</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #0d47a1;">Reviewing a skill you did not write is the situation you will actually be in &mdash; with the official skills in the next section, with a rule a teammate committed, with any convention handed to you as settled. Knowing that a skill can be confidently wrong, and knowing what to check, is the transferable part.</p>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ### G4. Apply the Skill
# MAGIC
# MAGIC Scaffold something new with the skill driving. The example we have provided is **QuickPoll**, a simple, single-question polling app. A user picks one option from a fixed list, submits a vote, and sees a chart depicting the results so far. You can try scaffolding this, or pick an idea of your own.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC #### G4.1 The Prompt
# MAGIC
# MAGIC Issue a new prompt that:
# MAGIC - describes the app in a sentence or two
# MAGIC - names the target folder
# MAGIC - uses Lakebase for persistence
# MAGIC - withholds deployment
# MAGIC - **references the `create-lakebase-app` skill explicitly**
# MAGIC
# MAGIC Use the example provided below if desired.
# MAGIC
# MAGIC <details style="margin:20px 0;border:1px solid #DCE0E2;border-radius:12px;overflow:hidden;background:#F9F7F4;">
# MAGIC   <summary style="cursor:pointer;font-weight:600;color:#2272B4;padding:14px 18px;background:#EEEDE9;font-size:0.92rem;">Click to reveal the reference prompt</summary>
# MAGIC   <div style="padding:16px 20px;font-family:'SF Mono','Cascadia Code','Fira Code',Consolas,monospace;font-size:0.82rem;line-height:1.55;color:#1B3139;white-space:pre-wrap;word-break:break-word;">Using the "create-lakebase-app" skill, scaffold a new Databricks App called "QuickPoll" in the "quick-poll" folder in my user home folder. It's a single-question poll: the user picks one option from a fixed list (for example "What should we build next? — Feature A / Feature B / Feature C"), submits their vote, and sees the results as a horizontal bar chart of vote counts per option. Store votes in Lakebase. Don't deploy — I'll handle that.</div>
# MAGIC </details>
# MAGIC
# MAGIC <div style="border-left: 4px solid #1976d2; background: #e3f2fd; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <strong style="color: #0d47a1;">About the Reference Code</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #0d47a1;">Running the following cell will copy a reference implementation of QuickPoll to a separate subfolder within your home folder. The reference code contains captured Genie Code output and provides a consistent baseline representative of the output you can expect with the skill in play. When you run the prompts, your output may look different from the reference, but important part is the Lakebase integration: this part should be flawless.</p>
# MAGIC </div>

# COMMAND ----------

# MAGIC %run ./Includes/install_reference_code $x="quick-poll"

# COMMAND ----------

# MAGIC %md
# MAGIC #### G4.2 Test Your Build
# MAGIC
# MAGIC As we did earlier, review the code. Deploy it using your app (ensuring the Lakebase resource is attached). Were there any unexpected errors? Any design decisions that surprised you?

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### G5. Writing Your Own Skill
# MAGIC
# MAGIC Authoring a skill from scratch is worth doing at least once, and you now know what a good
# MAGIC one looks like. The recipe is short: collect the rules you keep re-teaching the assistant,
# MAGIC ask Genie Code to draft a skill in the standard format, then review it against the four
# MAGIC checks above.
# MAGIC
# MAGIC For a Lakebase-backed app, the rules worth encoding are the ones that cost real time:
# MAGIC
# MAGIC <div style="display:grid; grid-template-columns:repeat(2, 1fr); gap:12px; margin:18px 0;">
# MAGIC   <div style="border:1px solid #DCE0E2; border-radius:12px; padding:14px 18px; background:#F9F7F4;">
# MAGIC     <div style="font-weight:700; color:#1B3139; margin-bottom:6px;">Declare dependencies</div>
# MAGIC     <div style="color:#5B6B73; font-size:0.93rem;">Always ship a <code>requirements.txt</code> with pinned versions, covering the database driver and the Databricks SDK. This is the one that bit you.</div>
# MAGIC   </div>
# MAGIC   <div style="border:1px solid #DCE0E2; border-radius:12px; padding:14px 18px; background:#F9F7F4;">
# MAGIC     <div style="font-weight:700; color:#1B3139; margin-bottom:6px;">Configuration from the environment</div>
# MAGIC     <div style="color:#5B6B73; font-size:0.93rem;">Read connection details from environment variables populated by the app resource, never hardcoded.</div>
# MAGIC   </div>
# MAGIC   <div style="border:1px solid #DCE0E2; border-radius:12px; padding:14px 18px; background:#F9F7F4;">
# MAGIC     <div style="font-weight:700; color:#1B3139; margin-bottom:6px;">The app owns its objects</div>
# MAGIC     <div style="color:#5B6B73; font-size:0.93rem;">Let the app create its own schema and tables at runtime, idempotently, so it owns what it manages.</div>
# MAGIC   </div>
# MAGIC   <div style="border:1px solid #DCE0E2; border-radius:12px; padding:14px 18px; background:#F9F7F4;">
# MAGIC     <div style="font-weight:700; color:#1B3139; margin-bottom:6px;">Parameterized SQL</div>
# MAGIC     <div style="color:#5B6B73; font-size:0.93rem;">Values as query parameters, never formatted into the statement string.</div>
# MAGIC   </div>
# MAGIC </div>
# MAGIC
# MAGIC For reference, the prompt we used to create the skill used here is as follows:
# MAGIC
# MAGIC <div class="code-card">
# MAGIC   <div class="code-card-header">
# MAGIC     <span class="code-card-lang">Plain Language</span>
# MAGIC     <button class="code-card-copy" onclick="copyCode(this)">
# MAGIC       <svg class="copy-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
# MAGIC         <rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/>
# MAGIC       </svg>
# MAGIC       <svg class="check-icon" style="display:none" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
# MAGIC         <polyline points="20 6 9 17 4 12"/>
# MAGIC       </svg>
# MAGIC       <span class="copy-label">Copy</span>
# MAGIC     </button>
# MAGIC   </div>
# MAGIC   <div id="code3" class="code-card-body"></div>
# MAGIC </div>
# MAGIC
# MAGIC <style>
# MAGIC   .code-card {
# MAGIC     font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
# MAGIC     border: 1px solid #DCE0E2;
# MAGIC     border-radius: 0.5rem;
# MAGIC     overflow: hidden;
# MAGIC     background: #F9F7F4;
# MAGIC     max-width: calc(100% - 16px);
# MAGIC     margin: 0.25rem 0;
# MAGIC   }
# MAGIC   .code-card-header {
# MAGIC     display: flex;
# MAGIC     align-items: center;
# MAGIC     justify-content: space-between;
# MAGIC     padding: 0.4rem 0.75rem;
# MAGIC     background: #EEEDE9;
# MAGIC     border-bottom: 1px solid #DCE0E2;
# MAGIC   }
# MAGIC   .code-card-lang {
# MAGIC     font-size: 0.7rem;
# MAGIC     font-weight: 600;
# MAGIC     text-transform: uppercase;
# MAGIC     letter-spacing: 0.1em;
# MAGIC     color: #5A6F77;
# MAGIC   }
# MAGIC   .code-card-copy {
# MAGIC     display: inline-flex;
# MAGIC     align-items: center;
# MAGIC     gap: 0.3rem;
# MAGIC     background: none;
# MAGIC     border: none;
# MAGIC     color: #5A6F77;
# MAGIC     cursor: pointer;
# MAGIC     padding: 0.2rem 0.4rem;
# MAGIC     border-radius: 0.25rem;
# MAGIC     font-size: 0.7rem;
# MAGIC     font-weight: 500;
# MAGIC     transition: color 0.15s, background 0.15s;
# MAGIC   }
# MAGIC   .code-card-copy:hover {
# MAGIC     color: #1B3139;
# MAGIC     background: rgba(0,0,0,0.05);
# MAGIC   }
# MAGIC   .code-card-copy.copied {
# MAGIC     color: #2272B4;
# MAGIC   }
# MAGIC   .code-card-copy svg {
# MAGIC     width: 14px;
# MAGIC     height: 14px;
# MAGIC   }
# MAGIC   .code-card-body {
# MAGIC     margin: 0;
# MAGIC     padding: 1rem;
# MAGIC     overflow-x: auto;
# MAGIC     font-family: 'SF Mono', 'Cascadia Code', 'Fira Code', Consolas, monospace;
# MAGIC     font-size: 0.82rem;
# MAGIC     line-height: 1.55;
# MAGIC     color: #1B3139;
# MAGIC     white-space: pre-wrap;
# MAGIC     word-break: break-word;
# MAGIC   }
# MAGIC </style>
# MAGIC <script>
# MAGIC function copyCode(btn) {
# MAGIC   var code = btn.closest('.code-card').querySelector('.code-card-body').textContent;
# MAGIC   var ta = document.createElement('textarea');
# MAGIC   ta.value = code; ta.style.position='fixed'; ta.style.opacity='0';
# MAGIC   document.body.appendChild(ta); ta.select();
# MAGIC   var ok=false; try { ok = document.execCommand('copy'); } catch(e) {}
# MAGIC   document.body.removeChild(ta);
# MAGIC   if (ok) {
# MAGIC     var l=btn.querySelector('.copy-label'), c=btn.querySelector('.copy-icon'), k=btn.querySelector('.check-icon');
# MAGIC     c.style.display='none'; k.style.display=''; l.textContent='Copied!'; btn.classList.add('copied');
# MAGIC     setTimeout(function(){ c.style.display=''; k.style.display='none'; l.textContent='Copy'; btn.classList.remove('copied'); }, 2000);
# MAGIC   }
# MAGIC }
# MAGIC document.getElementById('code3').textContent = [
# MAGIC   'Create a new Genie Code skill in my user skills folder called "create-lakebase-app". It should encode the correct patterns for standing up a new Lakebase-backed app so future scaffolds avoid encountering some of the issues I\'ve hit so far. The skill must enforce:',
# MAGIC   '',
# MAGIC   '1. a "requirements.txt" file with pinned versions of required libraries (including the most recent Databricks SDK and psycopg2-binary)',
# MAGIC   '2. use the current Lakebase Autoscaling API for generating the database credential token whenever new connections are instantiated',
# MAGIC   '3. reading the Lakebase project identity and PG connection details from environment variables populated by "app.yaml" using an app resource with the key "database" and "valueFrom" — never hardcoded',
# MAGIC   '4. the app idempotently creates its own schema and tables at runtime under its own identity; never pre-create outside the app since this leads to ownership/permission problems',
# MAGIC   '5. parameterized SQL only to avoid SQL injection.',
# MAGIC ].join('\n');
# MAGIC </script>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## H. Bonus: You Do Not Have to Write Them All Yourself
# MAGIC
# MAGIC Databricks maintains an open-source library of skills for AI coding assistants:
# MAGIC
# MAGIC <div style="max-width:900px;margin:18px 0;padding:18px 22px;background:#F9F7F4;border:1px solid #DCE0E2;border-left:4px solid #FF3621;border-radius:10px;">
# MAGIC   <div style="font-weight:700;color:#1B3139;margin-bottom:6px;">databricks/databricks-agent-skills</div>
# MAGIC   <div style="color:#5B6B73;font-size:0.93rem;margin-bottom:10px;">Around 30 skills covering Databricks Apps, Lakebase, DABs, Unity Catalog, Jobs, Pipelines, Model Serving, Genie Agents, synthetic data generation, and more.</div>
# MAGIC   <a href="https://github.com/databricks/databricks-agent-skills" style="color:#2272B4;font-weight:600;font-size:0.93rem;">github.com/databricks/databricks-agent-skills</a>
# MAGIC </div>
# MAGIC
# MAGIC Install them with the Databricks CLI, which detects your coding agent and puts them where
# MAGIC it expects to find them:
# MAGIC
# MAGIC ```bash
# MAGIC databricks aitools install
# MAGIC ```
# MAGIC
# MAGIC There are skills in there for `databricks-apps` and `databricks-lakebase` — which means
# MAGIC the ground covered by the skill you installed in section G is also covered officially, by
# MAGIC people who maintain it full time.
# MAGIC
# MAGIC <script>
# MAGIC (function() {
# MAGIC   var tags = [
# MAGIC     {text: '\u23f1 5 min'},
# MAGIC     {text: 'bonus', preset: 'red'},
# MAGIC   ];
# MAGIC   var presets = {
# MAGIC     default: 'background:#F9F7F4; border:1px solid #DCE0E2; color:#5A6F77;',
# MAGIC     blue:    'background:#EDF5FB; border:1px solid #B8D4E8; color:#2272B4;',
# MAGIC     red:     'background:#FFF0EE; border:1px solid #FFBDB4; color:#D4321C;',
# MAGIC     green:   'background:#E8F5E9; border:1px solid #A5D6A7; color:#2E7D32;'
# MAGIC   };
# MAGIC   var base = 'display:inline-block; border-radius:4px; padding:2px 8px; font-size:11px; font-weight:700; margin-left:10px; vertical-align:middle;';
# MAGIC   var el = document.currentScript;
# MAGIC   var h2 = null;
# MAGIC   while (el && !h2) {
# MAGIC     h2 = el.querySelector ? el.querySelector('h2') : null;
# MAGIC     if (!h2) el = el.parentElement;
# MAGIC   }
# MAGIC   if (!h2) return;
# MAGIC   tags.forEach(function(tag) {
# MAGIC     if (h2.querySelector('[data-tag="' + tag.text + '"]')) return;
# MAGIC     var span = document.createElement('span');
# MAGIC     span.setAttribute('data-tag', tag.text);
# MAGIC     span.style.cssText = base + (presets[tag.preset || 'default'] || tag.style || presets.default);
# MAGIC     span.textContent = tag.text;
# MAGIC     h2.appendChild(span);
# MAGIC   });
# MAGIC })();
# MAGIC </script>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### H1. Where to Go From Here
# MAGIC
# MAGIC <div style="display:grid; grid-template-columns:repeat(2, 1fr); gap:12px; margin:18px 0;">
# MAGIC   <div style="border:1px solid #DCE0E2; border-radius:12px; padding:14px 18px; background:#F9F7F4;">
# MAGIC     <div style="font-weight:700; color:#1B3139; margin-bottom:6px;">Your own patterns</div>
# MAGIC     <div style="color:#5B6B73; font-size:0.93rem;">Any practice you got right after getting it wrong a few times &mdash; a deployment convention, a testing approach, a house style &mdash; is a candidate for a skill of your own.</div>
# MAGIC   </div>
# MAGIC   <div style="border:1px solid #DCE0E2; border-radius:12px; padding:14px 18px; background:#F9F7F4;">
# MAGIC     <div style="font-weight:700; color:#1B3139; margin-bottom:6px;">Team-level skills</div>
# MAGIC     <div style="color:#5B6B73; font-size:0.93rem;">A skill checked into a shared repo means your whole team's assistants apply the same conventions. That is more durable than a wiki nobody reads.</div>
# MAGIC   </div>
# MAGIC   <div style="border:1px solid #DCE0E2; border-radius:12px; padding:14px 18px; background:#F9F7F4;">
# MAGIC     <div style="font-weight:700; color:#1B3139; margin-bottom:6px;">The habits, without the ceremony</div>
# MAGIC     <div style="color:#5B6B73; font-size:0.93rem;">Say what you want and what you do not. Change one thing at a time. Read it before you accept it. Paste the real error. That is the entire method.</div>
# MAGIC   </div>
# MAGIC   <div style="border:1px solid #DCE0E2; border-radius:12px; padding:14px 18px; background:#F9F7F4;">
# MAGIC     <div style="font-weight:700; color:#1B3139; margin-bottom:6px;">Genie Code beyond code</div>
# MAGIC     <div style="color:#5B6B73; font-size:0.93rem;">Seeding data was one example. Schema exploration, one-off data fixes, and "what is actually in this table" are all fair game.</div>
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC &copy; 2026 Databricks, Inc. All rights reserved. Apache, Apache Spark, Spark, the Spark Logo, Apache Iceberg, Iceberg, and the Apache Iceberg logo are trademarks of the <a href="https://www.apache.org/" target="_blank">Apache Software Foundation</a>.<br/><br/><a href="https://databricks.com/privacy-policy" target="_blank">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use" target="_blank">Terms of Use</a> | <a href="https://help.databricks.com/" target="_blank">Support</a>