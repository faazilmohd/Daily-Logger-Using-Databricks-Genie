import streamlit as st
from datetime import datetime, timezone

# ---------------------------------------------------------------------------
# In-memory store (will be replaced with a database later)
# ---------------------------------------------------------------------------
if "entries" not in st.session_state:
    st.session_state.entries = []

# ---------------------------------------------------------------------------
# Page config
# ---------------------------------------------------------------------------
st.set_page_config(page_title="Daily Logger", page_icon="\U0001f4d3", layout="centered")
st.title("\U0001f4d3 Daily Logger")
st.caption("A personal work journal \u2014 log what you did and what got in the way.")

# ---------------------------------------------------------------------------
# New-entry form
# ---------------------------------------------------------------------------
MOODS = ["\U0001f61e Rough", "\U0001f610 Meh", "\U0001f642 Okay", "\U0001f60a Good", "\U0001f929 Great"]

with st.form("new_entry", clear_on_submit=True):
    body = st.text_area("What did you work on today?", height=120)
    mood = st.select_slider("How was your day?", options=MOODS, value="\U0001f642 Okay")
    blockers = st.text_input("Blockers (optional \u2014 comma-separated)")
    submitted = st.form_submit_button("Save entry")

if submitted:
    if not body.strip():
        st.warning("Please write something before saving.")
    else:
        entry = {
            "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
            "body": body.strip(),
            "mood": mood,
            "blockers": [b.strip() for b in blockers.split(",") if b.strip()],
        }
        st.session_state.entries.insert(0, entry)  # newest first
        st.success("Entry saved!")

# ---------------------------------------------------------------------------
# Entry history
# ---------------------------------------------------------------------------
st.divider()
st.subheader("Entry history")

if not st.session_state.entries:
    st.info("No entries yet \u2014 write your first one above.")
else:
    for entry in st.session_state.entries:
        with st.container(border=True):
            col_date, col_mood = st.columns([3, 1])
            col_date.markdown(f"**{entry['timestamp']}**")
            col_mood.markdown(entry["mood"])
            st.markdown(entry["body"])
            if entry["blockers"]:
                st.markdown("**Blockers:** " + " \u00b7 ".join(entry["blockers"]))
